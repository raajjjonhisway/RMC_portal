using System.Security.Claims;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authentication.Cookies;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Caching.Memory;
using RanchiMunicipal.Data;
using RanchiMunicipal.Models;
using RanchiMunicipal.Services;

namespace RanchiMunicipal.Controllers.Admin;

public class AdminAccountController : Controller
{
    private readonly AppDbContext _db;
    private readonly IMemoryCache _cache;
    private readonly IAuditService _audit;

    public AdminAccountController(AppDbContext db, IMemoryCache cache, IAuditService audit)
    {
        _db = db;
        _cache = cache;
        _audit = audit;
    }

    [HttpGet("admin/login")]
    public IActionResult Login(string? returnUrl)
    {
        if (User.Identity?.IsAuthenticated == true) return Redirect("/admin");
        return View(AdminViews.Login, new LoginVm { ReturnUrl = returnUrl });
    }

    [HttpPost("admin/login")]
    public async Task<IActionResult> Login(LoginVm vm)
    {
        if (!ModelState.IsValid) return View(AdminViews.Login, vm);

        var key = "login:" + HttpContext.Connection.RemoteIpAddress;
        var fails = _cache.Get<int>(key);
        if (fails >= 5)
        {
            ModelState.AddModelError("", "Too many failed attempts. Try again in 15 minutes.");
            return View(AdminViews.Login, vm);
        }

        var user = await _db.AdminUsers.FirstOrDefaultAsync(u => u.Username == vm.Username.Trim());
        // Burn the same CPU time when the user is unknown so timing does not reveal valid usernames.
        var ok = false;
        if (user != null) ok = PasswordHelper.Verify(vm.Password, user.PasswordHash);
        else PasswordHelper.Hash(vm.Password);

        if (!ok || user == null || !user.IsActive)
        {
            _cache.Set(key, fails + 1, TimeSpan.FromMinutes(15));
            await Task.Delay(400);
            ModelState.AddModelError("", "Invalid username or password.");
            return View(AdminViews.Login, vm);
        }

        _cache.Remove(key);
        user.LastLoginOn = DateTime.Now;
        await _db.SaveChangesAsync();
        await SignInAsync(user);
        await _audit.LogAsync("Login", "Account", user.Username);

        if (user.MustChangePassword) return RedirectToAction(nameof(ChangePassword));
        return Url.IsLocalUrl(vm.ReturnUrl) ? Redirect(vm.ReturnUrl!) : Redirect("/admin");
    }

    [Authorize, HttpPost("admin/logout")]
    public async Task<IActionResult> Logout()
    {
        await HttpContext.SignOutAsync(CookieAuthenticationDefaults.AuthenticationScheme);
        return Redirect("/admin/login");
    }

    [Authorize, HttpGet("admin/change-password")]
    public IActionResult ChangePassword() => View(AdminViews.ChangePassword, new ChangePasswordVm());

    [Authorize, HttpPost("admin/change-password")]
    public async Task<IActionResult> ChangePassword(ChangePasswordVm vm)
    {
        if (!ModelState.IsValid) return View(AdminViews.ChangePassword, vm);

        var id = int.Parse(User.FindFirstValue(ClaimTypes.NameIdentifier)!);
        var user = await _db.AdminUsers.FindAsync(id);
        if (user == null || !PasswordHelper.Verify(vm.Current, user.PasswordHash))
        {
            ModelState.AddModelError(nameof(vm.Current), "Current password is incorrect.");
            return View(AdminViews.ChangePassword, vm);
        }
        if (vm.New == vm.Current)
        {
            ModelState.AddModelError(nameof(vm.New), "Choose a password different from the current one.");
            return View(AdminViews.ChangePassword, vm);
        }

        user.PasswordHash = PasswordHelper.Hash(vm.New);
        user.MustChangePassword = false;
        await _db.SaveChangesAsync();
        await SignInAsync(user); // refresh claims (clears "mustchange")
        await _audit.LogAsync("Change password", "Account", user.Username);
        TempData["ok"] = "Password changed.";
        return Redirect("/admin");
    }

    private Task SignInAsync(AdminUser user)
    {
        var claims = new List<Claim>
        {
            new(ClaimTypes.NameIdentifier, user.Id.ToString()),
            new(ClaimTypes.Name, user.Username),
            new("display", string.IsNullOrWhiteSpace(user.DisplayName) ? user.Username : user.DisplayName)
        };
        if (user.MustChangePassword) claims.Add(new Claim("mustchange", "1"));
        var principal = new ClaimsPrincipal(new ClaimsIdentity(claims, CookieAuthenticationDefaults.AuthenticationScheme));
        return HttpContext.SignInAsync(CookieAuthenticationDefaults.AuthenticationScheme, principal);
    }
}

public static class AdminViews
{
    public const string Login = "~/Views/Admin/Account/Login.cshtml";
    public const string ChangePassword = "~/Views/Admin/Account/ChangePassword.cshtml";
}
