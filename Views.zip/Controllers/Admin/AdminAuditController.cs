using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using RanchiMunicipal.Data;

namespace RanchiMunicipal.Controllers.Admin;

[Route("admin/activity")]
public class AdminAuditController : AdminBase
{
    private readonly AppDbContext _db;

    public AdminAuditController(AppDbContext db) => _db = db;

    [HttpGet("")]
    public async Task<IActionResult> Index() =>
        View(AdminView + "Audit/Index.cshtml", await _db.AuditLogs.AsNoTracking().OrderByDescending(a => a.Id).Take(300).ToListAsync());
}
