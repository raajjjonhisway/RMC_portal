using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Filters;

namespace RanchiMunicipal.Controllers.Admin;

/// <summary>Base for every admin controller: requires login and forces a password change after first login.</summary>
[Authorize]
public abstract class AdminBase : Controller
{
    protected const string AdminView = "~/Views/Admin/";

    public override void OnActionExecuting(ActionExecutingContext context)
    {
        if (User.HasClaim("mustchange", "1"))
            context.Result = RedirectToAction("ChangePassword", "AdminAccount");
        base.OnActionExecuting(context);
    }
}
