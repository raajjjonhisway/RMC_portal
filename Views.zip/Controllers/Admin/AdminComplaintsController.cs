using System.Text;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using RanchiMunicipal.Data;
using RanchiMunicipal.Models;
using RanchiMunicipal.Services;

namespace RanchiMunicipal.Controllers.Admin;

[Route("admin/complaints")]
public class AdminComplaintsController : AdminBase
{
    private const int PageSize = 20;
    private readonly AppDbContext _db;
    private readonly IAuditService _audit;

    public AdminComplaintsController(AppDbContext db, IAuditService audit)
    {
        _db = db;
        _audit = audit;
    }

    private IQueryable<Complaint> Filtered(string? status, string? q)
    {
        var query = _db.Complaints.AsNoTracking().AsQueryable();
        if (!string.IsNullOrEmpty(status) && Lookups.ComplaintStatuses.Contains(status)) query = query.Where(c => c.Status == status);
        if (!string.IsNullOrWhiteSpace(q))
        {
            var like = Lookups.Like(q.Trim());
            query = query.Where(c => EF.Functions.Like(c.TicketNo, like, "\\") || EF.Functions.Like(c.Name, like, "\\") ||
                                     EF.Functions.Like(c.Phone, like, "\\") || EF.Functions.Like(c.Category, like, "\\") ||
                                     EF.Functions.Like(c.Ward, like, "\\"));
        }
        return query;
    }

    [HttpGet("")]
    public async Task<IActionResult> Index(string? status, string? q, int page = 1)
    {
        var query = Filtered(status, q);
        var total = await query.CountAsync();
        var pages = Math.Max(1, (int)Math.Ceiling(total / (double)PageSize));
        page = Math.Clamp(page, 1, pages);
        var items = await query.OrderByDescending(c => c.CreatedOn).Skip((page - 1) * PageSize).Take(PageSize).ToListAsync();

        ViewData["Status"] = status;
        ViewData["Q"] = q;
        ViewData["Pager"] = new PagerVm
        {
            Page = page,
            TotalPages = pages,
            BaseUrl = $"/admin/complaints?status={Uri.EscapeDataString(status ?? "")}&q={Uri.EscapeDataString(q ?? "")}&page="
        };
        return View(AdminView + "Complaints/Index.cshtml", new ListVm<Complaint> { Items = items, Page = page, PageSize = PageSize, Total = total });
    }

    [HttpGet("{id:int}")]
    public async Task<IActionResult> Details(int id)
    {
        var c = await _db.Complaints.AsNoTracking().FirstOrDefaultAsync(x => x.Id == id);
        return c == null ? NotFound() : View(AdminView + "Complaints/Details.cshtml", c);
    }

    [HttpPost("{id:int}")]
    public async Task<IActionResult> Update(int id, string status, string? remark)
    {
        var c = await _db.Complaints.FirstOrDefaultAsync(x => x.Id == id);
        if (c == null) return NotFound();
        if (!Lookups.ComplaintStatuses.Contains(status)) return BadRequest();

        remark = (remark ?? "").Trim();
        if (remark.Length > 1000) remark = remark[..1000];

        var old = c.Status;
        c.Status = status;
        c.AdminRemark = remark;
        c.UpdatedOn = DateTime.Now;
        await _db.SaveChangesAsync();
        await _audit.LogAsync("Update", "Complaint", $"{c.TicketNo}: {old} → {status}");
        TempData["ok"] = "Complaint updated.";
        return Redirect($"/admin/complaints/{id}");
    }

    [HttpGet("export")]
    public async Task<IActionResult> Export(string? status, string? q)
    {
        var items = await Filtered(status, q).OrderByDescending(c => c.CreatedOn).Take(5000).ToListAsync();
        var sb = new StringBuilder();
        sb.AppendLine("Ticket,Filed on,Status,Category,Ward,Location,Name,Phone,Email,Description,Remark");
        foreach (var c in items)
        {
            sb.AppendLine(string.Join(",", new[]
            {
                Csv(c.TicketNo), Csv(c.CreatedOn.ToString("yyyy-MM-dd HH:mm")), Csv(c.Status), Csv(c.Category), Csv(c.Ward),
                Csv(c.Location), Csv(c.Name), Csv(c.Phone), Csv(c.Email), Csv(c.Description), Csv(c.AdminRemark)
            }));
        }
        await _audit.LogAsync("Export", "Complaint", $"{items.Count} rows");
        var enc = new UTF8Encoding(true);
        var bytes = enc.GetPreamble().Concat(enc.GetBytes(sb.ToString())).ToArray();
        return File(bytes, "text/csv", $"complaints-{DateTime.Now:yyyyMMdd-HHmm}.csv");
    }

    /// <summary>Quotes a CSV cell and neutralises spreadsheet formulas (=, +, -, @).</summary>
    private static string Csv(string? v)
    {
        v ??= "";
        if (v.Length > 0 && "=+-@\t\r".Contains(v[0])) v = "'" + v;
        return "\"" + v.Replace("\"", "\"\"") + "\"";
    }
}
