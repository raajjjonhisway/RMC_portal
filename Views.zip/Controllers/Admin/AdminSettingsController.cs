using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using RanchiMunicipal.Data;
using RanchiMunicipal.Models;
using RanchiMunicipal.Services;

namespace RanchiMunicipal.Controllers.Admin;

[Route("admin/settings")]
public class AdminSettingsController : AdminBase
{
    private readonly AppDbContext _db;
    private readonly ISiteService _site;
    private readonly IAuditService _audit;

    public AdminSettingsController(AppDbContext db, ISiteService site, IAuditService audit)
    {
        _db = db;
        _site = site;
        _audit = audit;
    }

    [HttpGet("")]
    public async Task<IActionResult> Index()
    {
        var values = await _db.Settings.AsNoTracking().ToDictionaryAsync(s => s.Key, s => s.Value);
        return View(AdminView + "Settings/Index.cshtml", values);
    }

    [HttpPost("")]
    public async Task<IActionResult> Save()
    {
        var form = await Request.ReadFormAsync();
        var rows = await _db.Settings.ToDictionaryAsync(s => s.Key);
        var errors = new Dictionary<string, string>();
        var posted = new Dictionary<string, string>();

        foreach (var def in SettingKeys.All)
        {
            var v = form[def.Key].ToString().Trim();
            posted[def.Key] = v;
            if (v.Length > 500) errors[def.Key] = "Maximum 500 characters.";
            else if (def.Options != null && !def.Options.Contains(v)) errors[def.Key] = "Choose a value from the list.";
            else if (def.Type == FieldType.Url && !Lookups.IsSafeUrl(v)) errors[def.Key] = "Use a link starting with /, #, http://, https://, tel: or mailto:";
        }

        if (errors.Count > 0)
        {
            ViewData["Errors"] = errors;
            return View(AdminView + "Settings/Index.cshtml", posted);
        }

        foreach (var def in SettingKeys.All)
        {
            if (rows.TryGetValue(def.Key, out var row)) row.Value = posted[def.Key];
            else _db.Settings.Add(new SiteSetting { Key = def.Key, Value = posted[def.Key] });
        }
        await _db.SaveChangesAsync();
        _site.Invalidate();
        await _audit.LogAsync("Update", "Site settings");
        TempData["ok"] = "Settings saved.";
        return Redirect("/admin/settings");
    }
}
