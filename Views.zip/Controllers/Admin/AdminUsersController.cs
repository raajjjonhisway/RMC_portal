using System.Security.Claims;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using RanchiMunicipal.Data;
using RanchiMunicipal.Models;
using RanchiMunicipal.Services;

namespace RanchiMunicipal.Controllers.Admin;

/// <summary>
/// Create / edit / deactivate / delete admin accounts. Kept separate from the generic CrudController
/// because passwords need hashing, and because accidental total lock-out must be prevented.
/// </summary>
[Route("admin/users")]
public class AdminUsersController : AdminBase
{
    private readonly AppDbContext _db;
    private readonly IAuditService _audit;

    public AdminUsersController(AppDbContext db, IAuditService audit)
    {
        _db = db;
        _audit = audit;
    }

    private int CurrentId => int.Parse(User.FindFirstValue(ClaimTypes.NameIdentifier)!);
    private const string ListView = AdminView + "Users/List.cshtml";
    private const string EditView = AdminView + "Users/Edit.cshtml";

    [HttpGet("")]
    public async Task<IActionResult> Index()
    {
        var meId = CurrentId;
        var rows = await _db.AdminUsers.AsNoTracking().OrderBy(u => u.Username)
            .Select(u => new AdminUserRowVm
            {
                Id = u.Id,
                Username = u.Username,
                DisplayName = u.DisplayName,
                IsActive = u.IsActive,
                MustChangePassword = u.MustChangePassword,
                CreatedOn = u.CreatedOn,
                LastLoginOn = u.LastLoginOn,
                IsSelf = u.Id == meId
            }).ToListAsync();
        return View(ListView, rows);
    }

    [HttpGet("create")]
    public IActionResult Create() => View(EditView, new AdminUserFormVm { IsNew = true, MustChangePassword = true });

    [HttpPost("create")]
    public async Task<IActionResult> CreatePost(AdminUserFormVm vm)
    {
        vm.IsNew = true;
        vm.Username = vm.Username.Trim();
        vm.DisplayName = vm.DisplayName.Trim();

        if (!ModelState.IsValid) { vm.Error = FirstModelError(); return View(EditView, vm); }
        if (string.IsNullOrWhiteSpace(vm.NewPassword) || vm.NewPassword.Length < 10)
        {
            vm.Error = "Enter an initial password of at least 10 characters.";
            return View(EditView, vm);
        }
        if (await _db.AdminUsers.AnyAsync(u => u.Username == vm.Username))
        {
            vm.Error = "That username is already taken.";
            return View(EditView, vm);
        }

        var user = new AdminUser
        {
            Username = vm.Username,
            DisplayName = vm.DisplayName,
            PasswordHash = PasswordHelper.Hash(vm.NewPassword),
            MustChangePassword = vm.MustChangePassword,
            IsActive = vm.IsActive,
            CreatedOn = DateTime.Now
        };
        _db.AdminUsers.Add(user);
        await _db.SaveChangesAsync();
        await _audit.LogAsync("Create", "Admin user", user.Username);
        TempData["ok"] = $"Admin account '{user.Username}' created.";
        return Redirect("/admin/users");
    }

    [HttpGet("edit/{id:int}")]
    public async Task<IActionResult> Edit(int id)
    {
        var u = await _db.AdminUsers.AsNoTracking().FirstOrDefaultAsync(x => x.Id == id);
        if (u == null) return NotFound();
        return View(EditView, new AdminUserFormVm
        {
            Id = u.Id,
            IsNew = false,
            IsSelf = u.Id == CurrentId,
            Username = u.Username,
            DisplayName = u.DisplayName,
            IsActive = u.IsActive,
            MustChangePassword = u.MustChangePassword
        });
    }

    [HttpPost("edit/{id:int}")]
    public async Task<IActionResult> EditPost(int id, AdminUserFormVm vm)
    {
        var u = await _db.AdminUsers.FirstOrDefaultAsync(x => x.Id == id);
        if (u == null) return NotFound();

        vm.Id = id;
        vm.IsNew = false;
        vm.IsSelf = u.Id == CurrentId;
        vm.Username = vm.Username.Trim();
        vm.DisplayName = vm.DisplayName.Trim();

        ModelState.Remove(nameof(vm.NewPassword));
        ModelState.Remove(nameof(vm.ConfirmPassword));
        if (!string.IsNullOrEmpty(vm.NewPassword) || !string.IsNullOrEmpty(vm.ConfirmPassword))
        {
            if (string.IsNullOrEmpty(vm.NewPassword) || vm.NewPassword.Length < 10) { vm.Error = "New password must be at least 10 characters."; return View(EditView, vm); }
            if (vm.NewPassword != vm.ConfirmPassword) { vm.Error = "Passwords do not match."; return View(EditView, vm); }
        }
        if (!ModelState.IsValid) { vm.Error = FirstModelError(); return View(EditView, vm); }
        if (await _db.AdminUsers.AnyAsync(x => x.Username == vm.Username && x.Id != id))
        {
            vm.Error = "That username is already taken.";
            return View(EditView, vm);
        }

        // Never leave the system with zero usable admin accounts.
        if (!vm.IsActive && u.IsActive)
        {
            var otherActive = await _db.AdminUsers.CountAsync(x => x.IsActive && x.Id != id);
            if (otherActive == 0)
            {
                vm.Error = "You cannot deactivate the last active admin account.";
                return View(EditView, vm);
            }
            if (vm.IsSelf)
            {
                vm.Error = "You cannot deactivate the account you are currently signed in with. Ask another admin to do this.";
                return View(EditView, vm);
            }
        }

        u.Username = vm.Username;
        u.DisplayName = vm.DisplayName;
        u.IsActive = vm.IsActive;
        if (!string.IsNullOrEmpty(vm.NewPassword))
        {
            u.PasswordHash = PasswordHelper.Hash(vm.NewPassword);
            u.MustChangePassword = true; // always force a real login change after an admin-set reset
        }
        // else: no password reset on this save, so leave MustChangePassword exactly as it already was —
        // the edit form has no control for it outside the reset-password section.

        await _db.SaveChangesAsync();
        await _audit.LogAsync("Update", "Admin user", u.Username);
        TempData["ok"] = string.IsNullOrEmpty(vm.NewPassword) ? "Saved." : "Saved. Password reset — the user must change it at next login.";
        return Redirect("/admin/users");
    }

    [HttpPost("delete/{id:int}")]
    public async Task<IActionResult> Delete(int id)
    {
        var u = await _db.AdminUsers.FirstOrDefaultAsync(x => x.Id == id);
        if (u == null) return NotFound();

        if (id == CurrentId)
        {
            TempData["err"] = "You cannot delete the account you are currently signed in with.";
            return Redirect("/admin/users");
        }
        var otherActive = await _db.AdminUsers.CountAsync(x => x.IsActive && x.Id != id);
        if (u.IsActive && otherActive == 0)
        {
            TempData["err"] = "You cannot delete the last active admin account.";
            return Redirect("/admin/users");
        }

        _db.AdminUsers.Remove(u);
        await _db.SaveChangesAsync();
        await _audit.LogAsync("Delete", "Admin user", u.Username);
        TempData["ok"] = "Admin account deleted.";
        return Redirect("/admin/users");
    }

    private string? FirstModelError() => ModelState.Values.SelectMany(v => v.Errors).Select(e => e.ErrorMessage).FirstOrDefault();
}
