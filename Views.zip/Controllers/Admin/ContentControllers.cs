using System.Text.RegularExpressions;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using RanchiMunicipal.Data;
using RanchiMunicipal.Models;
using RanchiMunicipal.Services;

namespace RanchiMunicipal.Controllers.Admin;

[Route("admin/slides")]
public class AdminSlidesController : CrudController<Slide>
{
    public AdminSlidesController(AppDbContext db, IFileUploader up, IAuditService a, ISiteService s) : base(db, up, a, s) { }
    protected override string Title => "Hero Slides";
    protected override string Slug => "slides";
    protected override string Icon => "bi-images";
    protected override IOrderedQueryable<Slide> Order(IQueryable<Slide> q) => q.OrderBy(x => x.SortOrder).ThenBy(x => x.Id);
    protected override IReadOnlyList<FieldDef> Fields { get; } = new FieldDef[]
    {
        new("Title", "Title (line 1)", Required: true, InList: true),
        new("Subtitle", "Title (line 2)", InList: true),
        new("Caption", "Caption", FieldType.TextArea),
        new("Theme", "Colour theme", FieldType.Select, true, Options: Lookups.Themes, Help: "Used when no image is uploaded, and behind the image."),
        new("ImagePath", "Background image", FieldType.Image, Help: "Wide image, e.g. 1600×420 (jpg, png, webp)."),
        new("LinkUrl", "Link", FieldType.Url, Help: "Optional. Page address such as /complaint or a full https:// link."),
        new("SortOrder", "Order", FieldType.Number, InList: true),
        new("IsActive", "Show on site", FieldType.Check, InList: true),
    };
}

[Route("admin/news")]
public class AdminNewsController : CrudController<NewsItem>
{
    public AdminNewsController(AppDbContext db, IFileUploader up, IAuditService a, ISiteService s) : base(db, up, a, s) { }
    protected override string Title => "News & Notices";
    protected override string Slug => "news";
    protected override string Icon => "bi-newspaper";
    protected override IOrderedQueryable<NewsItem> Order(IQueryable<NewsItem> q) => q.OrderByDescending(x => x.PublishedOn).ThenByDescending(x => x.Id);
    protected override IReadOnlyList<FieldDef> Fields { get; } = new FieldDef[]
    {
        new("Tag", "Type", FieldType.Select, true, true, Lookups.NewsTags),
        new("Title", "Headline", Required: true, InList: true),
        new("PublishedOn", "Date", FieldType.Date, true, true),
        new("Body", "Details", FieldType.Html, Help: "Simple HTML allowed (p, b, ul, li, a, table)."),
        new("AttachmentPath", "Attachment (PDF / Word / Excel / image)", FieldType.File),
        new("LinkUrl", "Link instead of detail page", FieldType.Url, Help: "Optional. If set, the headline links here."),
        new("IsActive", "Show on site", FieldType.Check, InList: true),
    };
}

[Route("admin/tenders")]
public class AdminTendersController : CrudController<Tender>
{
    public AdminTendersController(AppDbContext db, IFileUploader up, IAuditService a, ISiteService s) : base(db, up, a, s) { }
    protected override string Title => "Tenders / Quotations";
    protected override string Slug => "tenders";
    protected override string Icon => "bi-hammer";
    protected override IOrderedQueryable<Tender> Order(IQueryable<Tender> q) => q.OrderByDescending(x => x.PublishedOn).ThenByDescending(x => x.Id);
    protected override IReadOnlyList<FieldDef> Fields { get; } = new FieldDef[]
    {
        new("RefNo", "Reference no.", Required: true, InList: true),
        new("Title", "Title", Required: true, InList: true),
        new("Department", "Department", InList: true),
        new("PublishedOn", "Published on", FieldType.Date, true),
        new("LastDate", "Last date", FieldType.Date, true, true),
        new("DocumentPath", "Tender document", FieldType.File),
        new("IsActive", "Show on site", FieldType.Check, InList: true),
    };

    protected override async Task<string?> ValidateAsync(Tender e) =>
        e.LastDate < e.PublishedOn ? "Last date cannot be before the published date." : await Task.FromResult<string?>(null);
}

[Route("admin/pages")]
public class AdminPagesController : CrudController<ContentPage>
{
    public AdminPagesController(AppDbContext db, IFileUploader up, IAuditService a, ISiteService s) : base(db, up, a, s) { }
    protected override string Title => "Pages";
    protected override string Slug => "pages";
    protected override string Icon => "bi-file-earmark-richtext";
    protected override IOrderedQueryable<ContentPage> Order(IQueryable<ContentPage> q) => q.OrderBy(x => x.Title);
    protected override IReadOnlyList<FieldDef> Fields { get; } = new FieldDef[]
    {
        new("Title", "Page title", Required: true, InList: true),
        new("Slug", "Address (slug)", Required: true, InList: true, Help: "Lowercase letters, digits and hyphens. The page opens at /page/your-slug"),
        new("Body", "Content", FieldType.Html, Help: "Simple HTML allowed."),
        new("IsPublished", "Published", FieldType.Check, InList: true),
    };

    protected override void BeforeSave(ContentPage e, bool isNew) => e.UpdatedOn = DateTime.Now;

    protected override async Task<string?> ValidateAsync(ContentPage e)
    {
        if (!Regex.IsMatch(e.Slug, "^[a-z0-9-]{2,60}$")) return "Slug: use 2–60 lowercase letters, digits and hyphens.";
        if (await Db.Pages.AnyAsync(p => p.Slug == e.Slug && p.Id != e.Id)) return "That slug is already used by another page.";
        return null;
    }
}

[Route("admin/services")]
public class AdminServicesController : CrudController<ServiceCard>
{
    public AdminServicesController(AppDbContext db, IFileUploader up, IAuditService a, ISiteService s) : base(db, up, a, s) { }
    protected override string Title => "Service Cards";
    protected override string Slug => "services";
    protected override string Icon => "bi-grid";
    protected override IOrderedQueryable<ServiceCard> Order(IQueryable<ServiceCard> q) => q.OrderBy(x => x.SortOrder).ThenBy(x => x.Id);
    protected override IReadOnlyList<FieldDef> Fields { get; } = new FieldDef[]
    {
        new("Title", "Title", Required: true, InList: true),
        new("Description", "Description", FieldType.TextArea, Required: true),
        new("Icon", "Icon", FieldType.Icon, Help: "Bootstrap icon class, e.g. bi-house-check. Shown when no image is uploaded."),
        new("Theme", "Colour theme", FieldType.Select, true, Options: Lookups.Themes),
        new("ImagePath", "Image", FieldType.Image),
        new("Url", "Link", FieldType.Url, Required: true, InList: true),
        new("SortOrder", "Order", FieldType.Number, InList: true),
        new("IsActive", "Show on site", FieldType.Check, InList: true),
    };
}

[Route("admin/quicklinks")]
public class AdminQuickLinksController : CrudController<QuickLink>
{
    public AdminQuickLinksController(AppDbContext db, IFileUploader up, IAuditService a, ISiteService s) : base(db, up, a, s) { }
    protected override string Title => "Quick Links";
    protected override string Slug => "quicklinks";
    protected override string Icon => "bi-link-45deg";
    protected override IOrderedQueryable<QuickLink> Order(IQueryable<QuickLink> q) => q.OrderBy(x => x.SortOrder).ThenBy(x => x.Id);
    protected override IReadOnlyList<FieldDef> Fields { get; } = new FieldDef[]
    {
        new("Title", "Title", Required: true, InList: true),
        new("Icon", "Icon", FieldType.Icon, Help: "Bootstrap icon class, e.g. bi-newspaper"),
        new("Url", "Link", FieldType.Url, Required: true, InList: true),
        new("SortOrder", "Order", FieldType.Number, InList: true),
        new("IsActive", "Show on site", FieldType.Check, InList: true),
    };
}

[Route("admin/menu")]
public class AdminMenuController : CrudController<MenuItem>
{
    public AdminMenuController(AppDbContext db, IFileUploader up, IAuditService a, ISiteService s) : base(db, up, a, s) { }
    protected override string Title => "Menu Items";
    protected override string Slug => "menu";
    protected override string Icon => "bi-list-nested";
    protected override IOrderedQueryable<MenuItem> Order(IQueryable<MenuItem> q) => q.OrderBy(x => x.Section).ThenBy(x => x.SortOrder).ThenBy(x => x.Id);
    protected override IReadOnlyList<FieldDef> Fields { get; } = new FieldDef[]
    {
        new("Section", "Menu", FieldType.Select, true, true, MenuSections.All),
        new("Group", "Column heading (mega menu)", InList: true, MaxLength: 100, Help: "Items with the same heading are shown together in one column when the menu style is Mega. Leave empty for a plain list."),
        new("Title", "Label", Required: true, InList: true),
        new("Url", "Link", FieldType.Url, Required: true, InList: true),
        new("SortOrder", "Order", FieldType.Number, InList: true),
        new("IsActive", "Show on site", FieldType.Check, InList: true),
    };
}

[Route("admin/people")]
public class AdminPeopleController : CrudController<Person>
{
    public AdminPeopleController(AppDbContext db, IFileUploader up, IAuditService a, ISiteService s) : base(db, up, a, s) { }
    protected override string Title => "Officials & Elected";
    protected override string Slug => "people";
    protected override string Icon => "bi-person-badge";
    protected override IOrderedQueryable<Person> Order(IQueryable<Person> q) => q.OrderBy(x => x.Category).ThenBy(x => x.SortOrder).ThenBy(x => x.Name);
    protected override IReadOnlyList<FieldDef> Fields { get; } = new FieldDef[]
    {
        new("Category", "Wing", FieldType.Select, true, true, Lookups.PersonCategories,
            Help: "Elected = Mayor, Deputy Mayor, councillors (page /elected-wing). Official = Commissioner and officers (page /administration)."),
        new("Name", "Name", Required: true, InList: true, MaxLength: 200),
        new("Designation", "Designation", Required: true, InList: true, MaxLength: 200),
        new("PhotoPath", "Photo", FieldType.Image, Help: "Square portrait works best, e.g. 400×400 px (jpg, png, webp)."),
        new("Department", "Department", MaxLength: 200, Help: "Mainly for officials."),
        new("WardOrZone", "Ward / Zone", InList: true, MaxLength: 100, Help: "Mainly for elected representatives."),
        new("Party", "Party", MaxLength: 100),
        new("Term", "Term", MaxLength: 100, Help: "e.g. 2023 – 2028, or Since 2024."),
        new("Phone", "Phone", MaxLength: 30),
        new("Email", "Email", MaxLength: 150),
        new("OfficeAddress", "Office address", FieldType.TextArea, MaxLength: 300),
        new("Bio", "Profile", FieldType.Html, Help: "Optional short biography. Simple HTML allowed."),
        new("SortOrder", "Order", FieldType.Number, InList: true, Help: "Smaller numbers first (Mayor = 1, Deputy Mayor = 2 …)."),
        new("ShowOnHome", "Show on home page", FieldType.Check, InList: true, Help: "Needs at least one ticked person to display the Our Leadership section."),
        new("ShowContact", "Show phone / email / office publicly", FieldType.Check, Help: "Off by default. Tick only for official contact details that may be published."),
        new("IsActive", "Show on site", FieldType.Check, InList: true),
    };

    protected override Task<string?> ValidateAsync(Person e)
    {
        if (e.Email.Length > 0 && !Regex.IsMatch(e.Email, @"^[^@\s]+@[^@\s]+\.[^@\s]+$")) return Task.FromResult<string?>("Email: enter a valid address.");
        if (e.Phone.Length > 0 && !Regex.IsMatch(e.Phone, @"^[0-9+()\-\s,/]+$")) return Task.FromResult<string?>("Phone: use digits, spaces and + ( ) - , / only.");
        return Task.FromResult<string?>(null);
    }
}

[Route("admin/gallery-categories")]
public class AdminGalleryCategoriesController : CrudController<GalleryCategory>
{
    public AdminGalleryCategoriesController(AppDbContext db, IFileUploader up, IAuditService a, ISiteService s) : base(db, up, a, s) { }
    protected override string Title => "Gallery Categories";
    protected override string Slug => "gallery-categories";
    protected override string Icon => "bi-collection";
    protected override IOrderedQueryable<GalleryCategory> Order(IQueryable<GalleryCategory> q) => q.OrderBy(x => x.SortOrder).ThenBy(x => x.Name);
    protected override IReadOnlyList<FieldDef> Fields { get; } = new FieldDef[]
    {
        new("Name", "Category name", Required: true, InList: true, MaxLength: 100, Help: "Shown as a filter tab on the public gallery page, e.g. Events, Infrastructure."),
        new("SortOrder", "Order", FieldType.Number, InList: true),
        new("IsActive", "Show on site", FieldType.Check, InList: true),
    };

    protected override async Task<string?> ValidateAsync(GalleryCategory e)
    {
        if (await Db.GalleryCategories.AnyAsync(c => c.Name == e.Name && c.Id != e.Id)) return "That category name is already used.";
        return null;
    }
}

[Route("admin/gallery")]
public class AdminGalleryImagesController : CrudController<GalleryImage>
{
    public AdminGalleryImagesController(AppDbContext db, IFileUploader up, IAuditService a, ISiteService s) : base(db, up, a, s) { }
    protected override string Title => "Photo Gallery";
    protected override string Slug => "gallery";
    protected override string Icon => "bi-images";
    protected override IOrderedQueryable<GalleryImage> Order(IQueryable<GalleryImage> q) => q.OrderBy(x => x.Category).ThenBy(x => x.SortOrder).ThenByDescending(x => x.Id);

    // Category options come from the active Gallery Categories, so the list always matches Admin → Gallery Categories.
    protected override IReadOnlyList<FieldDef> Fields
    {
        get
        {
            var categories = Db.GalleryCategories.AsNoTracking().Where(c => c.IsActive)
                .OrderBy(c => c.SortOrder).ThenBy(c => c.Name).Select(c => c.Name).ToArray();
            return new FieldDef[]
            {
                new("Category", "Category", FieldType.Select, true, true, categories,
                    Help: categories.Length == 0 ? "Add at least one category first in Admin → Gallery Categories." : null),
                new("Title", "Title", Required: true, InList: true, MaxLength: 300),
                new("Caption", "Caption", FieldType.TextArea, MaxLength: 500),
                new("ImagePath", "Photo", FieldType.Image, Required: true, Help: "jpg, png or webp."),
                new("TakenOn", "Date taken", FieldType.Date, true, true),
                new("SortOrder", "Order", FieldType.Number, InList: true),
                new("ShowOnHome", "Show on home page", FieldType.Check, InList: true, Help: "Needs at least one ticked photo to display the gallery preview on the home page."),
                new("IsActive", "Show on site", FieldType.Check, InList: true),
            };
        }
    }

    protected override async Task<string?> ValidateAsync(GalleryImage e)
    {
        if (e.Category.Length > 0 && !await Db.GalleryCategories.AnyAsync(c => c.Name == e.Category && c.IsActive))
            return "Choose a category from the list.";
        return null;
    }
}
