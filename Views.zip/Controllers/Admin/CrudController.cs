using System.Globalization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using RanchiMunicipal.Data;
using RanchiMunicipal.Models;
using RanchiMunicipal.Services;

namespace RanchiMunicipal.Controllers.Admin;

/// <summary>
/// Generic list / create / edit / delete for simple content entities. A concrete controller only
/// describes its fields; validation (required, max length, safe URLs, dates, uploads) is shared.
/// </summary>
public abstract class CrudController<T> : AdminBase where T : class, IEntity, new()
{
    protected readonly AppDbContext Db;
    protected readonly IFileUploader Uploader;
    protected readonly IAuditService Audit;
    protected readonly ISiteService Site;

    protected CrudController(AppDbContext db, IFileUploader uploader, IAuditService audit, ISiteService site)
    {
        Db = db;
        Uploader = uploader;
        Audit = audit;
        Site = site;
    }

    protected abstract string Title { get; }
    protected abstract string Slug { get; }
    protected abstract IReadOnlyList<FieldDef> Fields { get; }
    protected virtual string Icon => "bi-list-ul";
    protected virtual IOrderedQueryable<T> Order(IQueryable<T> q) => q.OrderByDescending(x => x.Id);
    protected virtual void Defaults(T e) { }
    protected virtual void BeforeSave(T e, bool isNew) { }
    protected virtual Task<string?> ValidateAsync(T e) => Task.FromResult<string?>(null);

    private const string ListView = AdminView + "Crud/List.cshtml";
    private const string EditView = AdminView + "Crud/Edit.cshtml";

    // ---------- list ----------
    [HttpGet("")]
    public async Task<IActionResult> Index(string? q)
    {
        var items = await Order(Db.Set<T>().AsNoTracking()).Take(1000).ToListAsync();
        var cols = Fields.Where(f => f.InList).ToList();

        var rows = items.Select(e => new CrudRow
        {
            Id = e.Id,
            Cells = cols.Select(c => Display(c, Prop(c).GetValue(e))).ToList()
        }).ToList();

        if (!string.IsNullOrWhiteSpace(q))
            rows = rows.Where(r => r.Cells.Any(c => c.Contains(q.Trim(), StringComparison.OrdinalIgnoreCase))).ToList();

        return View(ListView, new CrudListVm { Title = Title, Slug = Slug, Icon = Icon, Columns = cols, Rows = rows, Q = q });
    }

    // ---------- create ----------
    [HttpGet("create")]
    public IActionResult Create()
    {
        var e = new T();
        Defaults(e);
        return View(EditView, NewEditVm(e, true));
    }

    [HttpPost("create")]
    public async Task<IActionResult> CreatePost()
    {
        var e = new T();
        Defaults(e);
        var vm = NewEditVm(e, true);
        var pendingDelete = new List<string>();
        if (!await BindAsync(e, vm.Fields, pendingDelete) || !await ValidOrSetError(e, vm))
            return View(EditView, vm);

        BeforeSave(e, true);
        Db.Set<T>().Add(e);
        await Db.SaveChangesAsync();
        Site.Invalidate();
        await Audit.LogAsync("Create", Title, Label(e));
        TempData["ok"] = "Saved.";
        return Redirect($"/admin/{Slug}");
    }

    // ---------- edit ----------
    [HttpGet("edit/{id:int}")]
    public async Task<IActionResult> Edit(int id)
    {
        var e = await Db.Set<T>().AsNoTracking().FirstOrDefaultAsync(x => x.Id == id);
        return e == null ? NotFound() : View(EditView, NewEditVm(e, false));
    }

    [HttpPost("edit/{id:int}")]
    public async Task<IActionResult> EditPost(int id)
    {
        var e = await Db.Set<T>().FirstOrDefaultAsync(x => x.Id == id);
        if (e == null) return NotFound();

        var vm = NewEditVm(e, false);
        var pendingDelete = new List<string>();
        if (!await BindAsync(e, vm.Fields, pendingDelete) || !await ValidOrSetError(e, vm))
        {
            Db.Entry(e).State = EntityState.Detached; // discard half-bound values
            return View(EditView, vm);
        }

        BeforeSave(e, false);
        await Db.SaveChangesAsync();
        foreach (var p in pendingDelete) Uploader.Delete(p);
        Site.Invalidate();
        await Audit.LogAsync("Update", Title, Label(e));
        TempData["ok"] = "Saved.";
        return Redirect($"/admin/{Slug}");
    }

    // ---------- delete ----------
    [HttpPost("delete/{id:int}")]
    public async Task<IActionResult> Delete(int id)
    {
        var e = await Db.Set<T>().FirstOrDefaultAsync(x => x.Id == id);
        if (e == null) return NotFound();

        var label = Label(e);
        var files = Fields.Where(f => f.Type is FieldType.File or FieldType.Image)
            .Select(f => Prop(f).GetValue(e) as string).ToList();
        Db.Set<T>().Remove(e);
        await Db.SaveChangesAsync();
        foreach (var f in files) Uploader.Delete(f);
        Site.Invalidate();
        await Audit.LogAsync("Delete", Title, label);
        TempData["ok"] = "Deleted.";
        return Redirect($"/admin/{Slug}");
    }

    // ---------- helpers ----------
    private async Task<bool> ValidOrSetError(T e, CrudEditVm vm)
    {
        var err = await ValidateAsync(e);
        if (err == null) return true;
        vm.Error = err;
        return false;
    }

    private CrudEditVm NewEditVm(T e, bool isNew) => new()
    {
        Title = Title,
        Slug = Slug,
        Id = e.Id,
        IsNew = isNew,
        Fields = Fields.Select(f => new FieldVm { Def = f, Value = Format(Prop(f).GetValue(e)) }).ToList()
    };

    private static System.Reflection.PropertyInfo Prop(FieldDef f) =>
        typeof(T).GetProperty(f.Prop) ?? throw new InvalidOperationException($"{typeof(T).Name}.{f.Prop} not found");

    private string Label(T e)
    {
        var f = Fields.FirstOrDefault(x => x.Type is FieldType.Text or FieldType.Select);
        return (f != null ? Prop(f).GetValue(e)?.ToString() : null) is { Length: > 0 } s ? $"#{e.Id} {s}" : $"#{e.Id}";
    }

    private static string Format(object? v) => v switch
    {
        null => "",
        DateTime d => d.ToString("yyyy-MM-dd", CultureInfo.InvariantCulture),
        bool b => b ? "true" : "false",
        _ => Convert.ToString(v, CultureInfo.InvariantCulture) ?? ""
    };

    private static string Display(FieldDef f, object? v)
    {
        if (f.Type == FieldType.Check) return v is true ? "✔" : "–";
        if (f.Type is FieldType.File or FieldType.Image) return string.IsNullOrEmpty(v as string) ? "–" : "📎";
        if (v is DateTime d) return d.ToString("dd MMM yyyy", CultureInfo.InvariantCulture);
        var s = Format(v);
        if (f.Type is FieldType.Html or FieldType.TextArea) s = System.Text.RegularExpressions.Regex.Replace(s, "<[^>]+>", " ");
        return s.Length > 90 ? s[..90] + "…" : s;
    }

    /// <summary>Reads the posted form into the entity and the field view-models. Returns false if any field is invalid.</summary>
    private async Task<bool> BindAsync(T e, List<FieldVm> vms, List<string> pendingDelete)
    {
        var form = await Request.ReadFormAsync();
        var ok = true;

        foreach (var vm in vms)
        {
            var f = vm.Def;
            var prop = Prop(f);
            var raw = form[f.Prop].ToString().Trim();
            vm.Error = null;

            switch (f.Type)
            {
                case FieldType.Check:
                    var b = form[f.Prop].Contains("true");
                    prop.SetValue(e, b);
                    vm.Value = b ? "true" : "false";
                    continue;

                case FieldType.File:
                case FieldType.Image:
                    var old = prop.GetValue(e) as string;
                    var file = form.Files.GetFile(f.Prop);
                    if (file != null && file.Length > 0)
                    {
                        var (path, err) = await Uploader.SaveAsync(file, f.Type == FieldType.Image);
                        if (err != null) { vm.Error = err; ok = false; }
                        else
                        {
                            if (!string.IsNullOrEmpty(old)) pendingDelete.Add(old);
                            prop.SetValue(e, path);
                        }
                    }
                    else if (form[f.Prop + "__remove"].Contains("true"))
                    {
                        if (!string.IsNullOrEmpty(old)) pendingDelete.Add(old);
                        prop.SetValue(e, "");
                    }
                    vm.Value = prop.GetValue(e) as string ?? "";
                    if (f.Required && vm.Value.Length == 0) { vm.Error = "Required."; ok = false; }
                    continue;

                case FieldType.Date:
                    vm.Value = raw;
                    if (raw.Length == 0) { vm.Error = "Required."; ok = false; break; }
                    if (!DateTime.TryParse(raw, CultureInfo.InvariantCulture, DateTimeStyles.None, out var dt))
                    { vm.Error = "Invalid date."; ok = false; break; }
                    prop.SetValue(e, dt);
                    break;

                case FieldType.Number:
                    vm.Value = raw;
                    if (raw.Length == 0) { prop.SetValue(e, 0); break; }
                    if (!int.TryParse(raw, NumberStyles.Integer, CultureInfo.InvariantCulture, out var n) || n < -100000 || n > 100000)
                    { vm.Error = "Enter a whole number."; ok = false; break; }
                    prop.SetValue(e, n);
                    break;

                default:
                    var text = f.Type == FieldType.Html ? HtmlCleaner.Clean(raw) : raw;
                    vm.Value = text;
                    if (f.Required && text.Length == 0) { vm.Error = "Required."; ok = false; break; }
                    if (text.Length > f.Max) { vm.Error = $"Maximum {f.Max} characters."; ok = false; break; }
                    if (f.Type == FieldType.Select && text.Length > 0 && f.Options != null && !f.Options.Contains(text))
                    { vm.Error = "Choose a value from the list."; ok = false; break; }
                    if (f.Type == FieldType.Url && !Lookups.IsSafeUrl(text))
                    { vm.Error = "Use a link starting with /, #, http://, https://, tel: or mailto:"; ok = false; break; }
                    if (f.Type == FieldType.Icon && text.Length > 0 && !System.Text.RegularExpressions.Regex.IsMatch(text, @"^bi-[a-z0-9-]+$"))
                    { vm.Error = "Use a Bootstrap icon class such as bi-house."; ok = false; break; }
                    prop.SetValue(e, text);
                    break;
            }
        }
        return ok;
    }
}
