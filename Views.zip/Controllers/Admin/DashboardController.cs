using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using RanchiMunicipal.Data;
using RanchiMunicipal.Models;

namespace RanchiMunicipal.Controllers.Admin;

[Route("admin")]
public class DashboardController : AdminBase
{
    private readonly AppDbContext _db;

    public DashboardController(AppDbContext db) => _db = db;

    [HttpGet("")]
    public async Task<IActionResult> Index()
    {
        var today = DateTime.Today;
        var byCat = await _db.Complaints.AsNoTracking().GroupBy(c => c.Category)
            .Select(g => new { g.Key, N = g.Count() }).OrderByDescending(x => x.N).Take(6).ToListAsync();

        var vm = new DashboardVm
        {
            News = await _db.News.CountAsync(),
            OpenTenders = await _db.Tenders.CountAsync(t => t.IsActive && t.LastDate >= today),
            Pages = await _db.Pages.CountAsync(),
            Total = await _db.Complaints.CountAsync(),
            New = await _db.Complaints.CountAsync(c => c.Status == "New"),
            InProgress = await _db.Complaints.CountAsync(c => c.Status == "In Progress"),
            Resolved = await _db.Complaints.CountAsync(c => c.Status == "Resolved"),
            ByCategory = byCat.Select(x => new KeyValuePair<string, int>(x.Key, x.N)).ToList(),
            Recent = await _db.Complaints.AsNoTracking().OrderByDescending(c => c.CreatedOn).Take(6).ToListAsync(),
            Activity = await _db.AuditLogs.AsNoTracking().OrderByDescending(a => a.Id).Take(8).ToListAsync()
        };
        return View(AdminView + "Dashboard/Index.cshtml", vm);
    }
}
