using System.Security.Cryptography;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Caching.Memory;
using RanchiMunicipal.Data;
using RanchiMunicipal.Models;

namespace RanchiMunicipal.Controllers;

public class ComplaintController : Controller
{
    private readonly AppDbContext _db;
    private readonly IMemoryCache _cache;

    public ComplaintController(AppDbContext db, IMemoryCache cache)
    {
        _db = db;
        _cache = cache;
    }

    [HttpGet("complaint")]
    public IActionResult Create() => View(new ComplaintForm());

    [HttpPost("complaint")]
    public async Task<IActionResult> Create(ComplaintForm form)
    {
        // Honeypot: bots fill this hidden field.
        if (!string.IsNullOrEmpty(form.Website)) return RedirectToAction("Index", "Home");

        if (!Lookups.ComplaintCategories.Contains(form.Category))
            ModelState.AddModelError(nameof(form.Category), "Please choose a category.");

        if (!ModelState.IsValid) return View(form);

        if (Throttled("cmp", 5, TimeSpan.FromHours(1)))
        {
            ModelState.AddModelError("", "Too many complaints from this connection. Please try again later or call the toll free number.");
            return View(form);
        }

        string ticket;
        do
        {
            ticket = "RMC" + DateTime.Now.ToString("yyMMdd") + RandomNumberGenerator.GetInt32(10000, 100000);
        } while (await _db.Complaints.AnyAsync(c => c.TicketNo == ticket));

        _db.Complaints.Add(new Complaint
        {
            TicketNo = ticket,
            Name = form.Name.Trim(),
            Phone = form.Phone.Trim(),
            Email = form.Email?.Trim() ?? "",
            Category = form.Category,
            Ward = form.Ward?.Trim() ?? "",
            Location = form.Location?.Trim() ?? "",
            Description = form.Description.Trim()
        });
        await _db.SaveChangesAsync();
        return RedirectToAction(nameof(Success), new { ticket });
    }

    [HttpGet("complaint/success/{ticket}")]
    public IActionResult Success(string ticket) => View((object)ticket);

    [HttpGet("complaint/track")]
    public IActionResult Track() => View(new TrackForm());

    [HttpPost("complaint/track")]
    public async Task<IActionResult> Track(TrackForm form)
    {
        if (!ModelState.IsValid) return View(form);
        if (Throttled("trk", 10, TimeSpan.FromMinutes(15)))
        {
            ModelState.AddModelError("", "Too many attempts. Please try again in a few minutes.");
            return View(form);
        }

        var ticket = form.Ticket.Trim().ToUpperInvariant();
        var phone = form.Phone.Trim();
        var c = await _db.Complaints.AsNoTracking().FirstOrDefaultAsync(x => x.TicketNo == ticket && x.Phone == phone);
        if (c == null)
        {
            ModelState.AddModelError("", "No complaint found for this ticket number and mobile number.");
            return View(form);
        }
        ViewData["Found"] = c;
        return View(form);
    }

    private bool Throttled(string prefix, int max, TimeSpan window)
    {
        var key = $"{prefix}:{HttpContext.Connection.RemoteIpAddress}";
        var count = _cache.GetOrCreate(key, e => { e.AbsoluteExpirationRelativeToNow = window; return new int[1]; })!;
        return Interlocked.Increment(ref count[0]) > max;
    }
}
