using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using RanchiMunicipal.Data;
using RanchiMunicipal.Models;

namespace RanchiMunicipal.Controllers;

/// <summary>Public photo gallery, filterable by category.</summary>
public class GalleryController : Controller
{
    private const int PageSize = 24;
    private readonly AppDbContext _db;

    public GalleryController(AppDbContext db) => _db = db;

    [HttpGet("gallery")]
    public async Task<IActionResult> Index(string? category, int page = 1)
    {
        category = (category ?? "").Trim();
        if (category.Length > 100) category = category[..100];

        var categories = await _db.GalleryCategories.AsNoTracking().Where(c => c.IsActive)
            .OrderBy(c => c.SortOrder).ThenBy(c => c.Name).Select(c => c.Name).ToListAsync();

        var query = _db.GalleryImages.AsNoTracking().Where(g => g.IsActive);
        if (category.Length > 0 && categories.Contains(category))
            query = query.Where(g => g.Category == category);
        else
            category = "";

        var total = await query.CountAsync();
        var pages = Math.Max(1, (int)Math.Ceiling(total / (double)PageSize));
        page = Math.Clamp(page, 1, pages);
        var items = await query.OrderByDescending(g => g.TakenOn).ThenByDescending(g => g.SortOrder).ThenByDescending(g => g.Id)
            .Skip((page - 1) * PageSize).Take(PageSize).ToListAsync();

        ViewData["Categories"] = categories;
        ViewData["Category"] = category;
        ViewData["Pager"] = new PagerVm { Page = page, TotalPages = pages, BaseUrl = $"/gallery?category={Uri.EscapeDataString(category)}&page=" };
        return View(new ListVm<GalleryImage> { Items = items, Page = page, PageSize = PageSize, Total = total });
    }
}
