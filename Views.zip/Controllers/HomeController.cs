using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using RanchiMunicipal.Data;
using RanchiMunicipal.Models;
using RanchiMunicipal.Services;

namespace RanchiMunicipal.Controllers;

public class HomeController : Controller
{
    private readonly AppDbContext _db;
    private readonly ISiteService _site;

    public HomeController(AppDbContext db, ISiteService site)
    {
        _db = db;
        _site = site;
    }

    public async Task<IActionResult> Index()
    {
        var s = _site.GetSite();
        var digits = new string(s.TollFree.Where(char.IsDigit).ToArray());
        var wa = new string(s.WhatsApp.Where(char.IsDigit).ToArray());
        if (wa.Length == 10) wa = "91" + wa;

        var vm = new HomeViewModel
        {
            Site = s,
            Slides = await _db.Slides.AsNoTracking().Where(x => x.IsActive).OrderBy(x => x.SortOrder).ThenBy(x => x.Id).ToListAsync(),
            News = await _db.News.AsNoTracking().Where(x => x.IsActive).OrderByDescending(x => x.PublishedOn).ThenByDescending(x => x.Id).Take(12).ToListAsync(),
            Services = await _db.Services.AsNoTracking().Where(x => x.IsActive).OrderBy(x => x.SortOrder).ThenBy(x => x.Id).ToListAsync(),
            QuickLinks = await _db.QuickLinks.AsNoTracking().Where(x => x.IsActive).OrderBy(x => x.SortOrder).ThenBy(x => x.Id).ToListAsync(),
            Leaders = await _db.People.AsNoTracking().Where(x => x.IsActive && x.ShowOnHome).OrderBy(x => x.Category).ThenBy(x => x.SortOrder).ThenBy(x => x.Name).Take(8).ToListAsync(),
            GalleryPreview = await _db.GalleryImages.AsNoTracking().Where(x => x.IsActive && x.ShowOnHome).OrderByDescending(x => x.TakenOn).ThenBy(x => x.SortOrder).Take(8).ToListAsync(),
            Channels = new[]
            {
                new ComplaintChannel("Toll Free Number", s.TollFree, "bi-headset", $"tel:{digits}", "#1f6fd0"),
                new ComplaintChannel("WhatsApp", s.WhatsApp, "bi-whatsapp", $"https://wa.me/{wa}", "#25d366"),
                new ComplaintChannel(s.NameEn + " Mobile App", "Download the App", "bi-phone", s.MobileAppUrl, "#1f2937"),
                new ComplaintChannel(s.NameEn + " Website", "Lodge Online", "bi-globe2", "/complaint", "#1f6fd0")
            }
        };
        return View(vm);
    }

    [HttpGet("search")]
    public async Task<IActionResult> Search(string? q)
    {
        q = (q ?? "").Trim();
        if (q.Length > 100) q = q[..100];
        if (q.Length < 2) return View(new SearchVm { Q = q });

        var like = Lookups.Like(q);
        var vm = new SearchVm
        {
            Q = q,
            News = await _db.News.AsNoTracking().Where(n => n.IsActive && (EF.Functions.Like(n.Title, like, "\\") || EF.Functions.Like(n.Body, like, "\\")))
                .OrderByDescending(n => n.PublishedOn).Take(20).ToListAsync(),
            Tenders = await _db.Tenders.AsNoTracking().Where(t => t.IsActive && (EF.Functions.Like(t.Title, like, "\\") || EF.Functions.Like(t.RefNo, like, "\\") || EF.Functions.Like(t.Department, like, "\\")))
                .OrderByDescending(t => t.PublishedOn).Take(20).ToListAsync(),
            Pages = await _db.Pages.AsNoTracking().Where(p => p.IsPublished && (EF.Functions.Like(p.Title, like, "\\") || EF.Functions.Like(p.Body, like, "\\")))
                .OrderBy(p => p.Title).Take(20).ToListAsync()
        };
        return View(vm);
    }

    [HttpGet("contact")]
    public IActionResult Contact() => View();

    [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
    public IActionResult Error() => View();
}
