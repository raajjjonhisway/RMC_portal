using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using RanchiMunicipal.Data;
using RanchiMunicipal.Models;

namespace RanchiMunicipal.Controllers;

public class NewsController : Controller
{
    private const int PageSize = 10;
    private readonly AppDbContext _db;

    public NewsController(AppDbContext db) => _db = db;

    [HttpGet("news")]
    public async Task<IActionResult> Index(string? tag, int page = 1)
    {
        if (tag != null && !Lookups.NewsTags.Contains(tag)) tag = null;
        var q = _db.News.AsNoTracking().Where(n => n.IsActive);
        if (tag != null) q = q.Where(n => n.Tag == tag);

        var total = await q.CountAsync();
        var pages = Math.Max(1, (int)Math.Ceiling(total / (double)PageSize));
        page = Math.Clamp(page, 1, pages);
        var items = await q.OrderByDescending(n => n.PublishedOn).ThenByDescending(n => n.Id)
            .Skip((page - 1) * PageSize).Take(PageSize).ToListAsync();

        ViewData["Tag"] = tag;
        ViewData["Pager"] = new PagerVm
        {
            Page = page,
            TotalPages = pages,
            BaseUrl = "/news?" + (tag != null ? "tag=" + Uri.EscapeDataString(tag) + "&" : "") + "page="
        };
        return View(new ListVm<NewsItem> { Items = items, Page = page, PageSize = PageSize, Total = total });
    }

    [HttpGet("news/{id:int}")]
    public async Task<IActionResult> Details(int id)
    {
        var item = await _db.News.AsNoTracking().FirstOrDefaultAsync(n => n.Id == id && n.IsActive);
        return item == null ? NotFound() : View(item);
    }
}
