using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using RanchiMunicipal.Data;

namespace RanchiMunicipal.Controllers;

public class PageController : Controller
{
    private readonly AppDbContext _db;

    public PageController(AppDbContext db) => _db = db;

    [HttpGet("page/{slug}")]
    public async Task<IActionResult> Show(string slug)
    {
        var page = await _db.Pages.AsNoTracking().FirstOrDefaultAsync(p => p.Slug == slug && p.IsPublished);
        return page == null ? NotFound() : View(page);
    }
}
