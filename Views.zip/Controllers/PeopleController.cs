using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using RanchiMunicipal.Data;
using RanchiMunicipal.Models;

namespace RanchiMunicipal.Controllers;

/// <summary>Public pages for elected representatives and officials.</summary>
public class PeopleController : Controller
{
    private const int PageSize = 24;
    private readonly AppDbContext _db;

    public PeopleController(AppDbContext db) => _db = db;

    [HttpGet("elected-wing")]
    public Task<IActionResult> Elected(string? q, int page = 1) =>
        List("Elected", "Elected Wing", "/elected-wing", "Mayor, Deputy Mayor and elected councillors of the corporation.", q, page);

    [HttpGet("administration")]
    public Task<IActionResult> Administration(string? q, int page = 1) =>
        List("Official", "Administrative Wing", "/administration", "Municipal Commissioner and senior officials of the corporation.", q, page);

    [HttpGet("people/{id:int}")]
    public async Task<IActionResult> Details(int id)
    {
        var p = await _db.People.AsNoTracking().FirstOrDefaultAsync(x => x.Id == id && x.IsActive);
        return p == null ? NotFound() : View(p);
    }

    private async Task<IActionResult> List(string category, string title, string path, string intro, string? q, int page)
    {
        q = (q ?? "").Trim();
        if (q.Length > 100) q = q[..100];

        var query = _db.People.AsNoTracking().Where(p => p.IsActive && p.Category == category);
        if (q.Length > 0)
        {
            var like = Lookups.Like(q);
            query = query.Where(p => EF.Functions.Like(p.Name, like, "\\") || EF.Functions.Like(p.Designation, like, "\\") ||
                                     EF.Functions.Like(p.Department, like, "\\") || EF.Functions.Like(p.WardOrZone, like, "\\") ||
                                     EF.Functions.Like(p.Party, like, "\\"));
        }

        var total = await query.CountAsync();
        var pages = Math.Max(1, (int)Math.Ceiling(total / (double)PageSize));
        page = Math.Clamp(page, 1, pages);
        var items = await query.OrderBy(p => p.SortOrder).ThenBy(p => p.Name)
            .Skip((page - 1) * PageSize).Take(PageSize).ToListAsync();

        ViewData["PageTitle"] = title;
        ViewData["Intro"] = intro;
        ViewData["Path"] = path;
        ViewData["Q"] = q;
        ViewData["Elected"] = category == "Elected";
        ViewData["Pager"] = new PagerVm { Page = page, TotalPages = pages, BaseUrl = $"{path}?q={Uri.EscapeDataString(q)}&page=" };
        return View("List", new ListVm<Person> { Items = items, Page = page, PageSize = PageSize, Total = total });
    }
}
