using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using RanchiMunicipal.Data;
using RanchiMunicipal.Models;

namespace RanchiMunicipal.Controllers;

public class TendersController : Controller
{
    private const int PageSize = 15;
    private readonly AppDbContext _db;

    public TendersController(AppDbContext db) => _db = db;

    [HttpGet("tenders")]
    public async Task<IActionResult> Index(string? q, string? status, int page = 1)
    {
        q = (q ?? "").Trim();
        if (q.Length > 100) q = q[..100];
        status = status is "open" or "closed" ? status : "all";

        var today = DateTime.Today;
        var query = _db.Tenders.AsNoTracking().Where(t => t.IsActive);
        if (q.Length > 0)
        {
            var like = Lookups.Like(q);
            query = query.Where(t => EF.Functions.Like(t.Title, like, "\\") || EF.Functions.Like(t.RefNo, like, "\\") || EF.Functions.Like(t.Department, like, "\\"));
        }
        if (status == "open") query = query.Where(t => t.LastDate >= today);
        if (status == "closed") query = query.Where(t => t.LastDate < today);

        var total = await query.CountAsync();
        var pages = Math.Max(1, (int)Math.Ceiling(total / (double)PageSize));
        page = Math.Clamp(page, 1, pages);
        var items = await query.OrderByDescending(t => t.PublishedOn).ThenByDescending(t => t.Id)
            .Skip((page - 1) * PageSize).Take(PageSize).ToListAsync();

        ViewData["Q"] = q;
        ViewData["Status"] = status;
        ViewData["Pager"] = new PagerVm
        {
            Page = page,
            TotalPages = pages,
            BaseUrl = $"/tenders?q={Uri.EscapeDataString(q)}&status={status}&page="
        };
        return View(new ListVm<Tender> { Items = items, Page = page, PageSize = PageSize, Total = total });
    }
}
