using Microsoft.EntityFrameworkCore;

namespace RanchiMunicipal.Data;

public class AppDbContext : DbContext
{
    public AppDbContext(DbContextOptions<AppDbContext> options) : base(options) { }

    public DbSet<AdminUser> AdminUsers => Set<AdminUser>();
    public DbSet<Slide> Slides => Set<Slide>();
    public DbSet<NewsItem> News => Set<NewsItem>();
    public DbSet<Tender> Tenders => Set<Tender>();
    public DbSet<ContentPage> Pages => Set<ContentPage>();
    public DbSet<ServiceCard> Services => Set<ServiceCard>();
    public DbSet<QuickLink> QuickLinks => Set<QuickLink>();
    public DbSet<MenuItem> MenuItems => Set<MenuItem>();
    public DbSet<Person> People => Set<Person>();
    public DbSet<GalleryCategory> GalleryCategories => Set<GalleryCategory>();
    public DbSet<GalleryImage> GalleryImages => Set<GalleryImage>();
    public DbSet<Complaint> Complaints => Set<Complaint>();
    public DbSet<SiteSetting> Settings => Set<SiteSetting>();
    public DbSet<AuditLog> AuditLogs => Set<AuditLog>();

    protected override void OnModelCreating(ModelBuilder b)
    {
        b.Entity<AdminUser>().HasIndex(u => u.Username).IsUnique();
        b.Entity<Complaint>().HasIndex(c => c.TicketNo).IsUnique();
        b.Entity<ContentPage>().HasIndex(p => p.Slug).IsUnique();
        b.Entity<Complaint>().HasIndex(c => new { c.Status, c.CreatedOn });
        b.Entity<NewsItem>().HasIndex(n => new { n.IsActive, n.PublishedOn });
        b.Entity<Tender>().HasIndex(t => t.LastDate);
        b.Entity<MenuItem>().HasIndex(m => new { m.Section, m.SortOrder });
        b.Entity<Person>().HasIndex(p => new { p.Category, p.IsActive, p.SortOrder });
        b.Entity<GalleryCategory>().HasIndex(c => c.Name).IsUnique();
        b.Entity<GalleryImage>().HasIndex(i => new { i.Category, i.IsActive, i.SortOrder });
    }
}
