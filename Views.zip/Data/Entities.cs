using System.ComponentModel.DataAnnotations;

namespace RanchiMunicipal.Data;

// Column sizes below are mirrored in Database/CreateDatabase.sql – keep both in sync.

public interface IEntity { int Id { get; set; } }

public class AdminUser
{
    public int Id { get; set; }
    [MaxLength(50)] public string Username { get; set; } = "";
    [MaxLength(200)] public string PasswordHash { get; set; } = "";
    [MaxLength(100)] public string DisplayName { get; set; } = "";
    public bool MustChangePassword { get; set; }
    public bool IsActive { get; set; } = true;
    public DateTime CreatedOn { get; set; } = DateTime.Now;
    public DateTime? LastLoginOn { get; set; }
}

public class Slide : IEntity
{
    public int Id { get; set; }
    [MaxLength(300)] public string Title { get; set; } = "";
    [MaxLength(300)] public string Subtitle { get; set; } = "";
    [MaxLength(4000)] public string Caption { get; set; } = "";
    [MaxLength(30)] public string Theme { get; set; } = "Ocean";
    [MaxLength(300)] public string ImagePath { get; set; } = "";
    [MaxLength(500)] public string LinkUrl { get; set; } = "";
    public int SortOrder { get; set; }
    public bool IsActive { get; set; } = true;
}

public class NewsItem : IEntity
{
    public int Id { get; set; }
    [MaxLength(30)] public string Tag { get; set; } = "Notice";
    [MaxLength(300)] public string Title { get; set; } = "";
    public string Body { get; set; } = "";                       // nvarchar(max)
    public DateTime PublishedOn { get; set; } = DateTime.Today;
    [MaxLength(300)] public string AttachmentPath { get; set; } = "";
    [MaxLength(500)] public string LinkUrl { get; set; } = "";
    public bool IsActive { get; set; } = true;
}

public class Tender : IEntity
{
    public int Id { get; set; }
    [MaxLength(300)] public string RefNo { get; set; } = "";
    [MaxLength(300)] public string Title { get; set; } = "";
    [MaxLength(300)] public string Department { get; set; } = "";
    public DateTime PublishedOn { get; set; } = DateTime.Today;
    public DateTime LastDate { get; set; } = DateTime.Today.AddDays(15);
    [MaxLength(300)] public string DocumentPath { get; set; } = "";
    public bool IsActive { get; set; } = true;
}

public class ContentPage : IEntity
{
    public int Id { get; set; }
    [MaxLength(60)] public string Slug { get; set; } = "";
    [MaxLength(300)] public string Title { get; set; } = "";
    public string Body { get; set; } = "";                       // nvarchar(max)
    public bool IsPublished { get; set; } = true;
    public DateTime UpdatedOn { get; set; } = DateTime.Now;
}

public class ServiceCard : IEntity
{
    public int Id { get; set; }
    [MaxLength(300)] public string Title { get; set; } = "";
    [MaxLength(4000)] public string Description { get; set; } = "";
    [MaxLength(300)] public string Icon { get; set; } = "bi-info-circle";
    [MaxLength(30)] public string Theme { get; set; } = "Ocean";
    [MaxLength(300)] public string ImagePath { get; set; } = "";
    [MaxLength(500)] public string Url { get; set; } = "";
    public int SortOrder { get; set; }
    public bool IsActive { get; set; } = true;
}

public class QuickLink : IEntity
{
    public int Id { get; set; }
    [MaxLength(300)] public string Title { get; set; } = "";
    [MaxLength(300)] public string Icon { get; set; } = "bi-link-45deg";
    [MaxLength(500)] public string Url { get; set; } = "";
    public int SortOrder { get; set; }
    public bool IsActive { get; set; } = true;
}

/// <summary>A gallery category (e.g. "Events", "Infrastructure", "Swachh Bharat Drive").</summary>
public class GalleryCategory : IEntity
{
    public int Id { get; set; }
    [MaxLength(100)] public string Name { get; set; } = "";
    public int SortOrder { get; set; }
    public bool IsActive { get; set; } = true;
}

/// <summary>One photo in the public gallery, filed under a category by name.</summary>
public class GalleryImage : IEntity
{
    public int Id { get; set; }
    [MaxLength(100)] public string Category { get; set; } = "";
    [MaxLength(300)] public string Title { get; set; } = "";
    [MaxLength(500)] public string Caption { get; set; } = "";
    [MaxLength(300)] public string ImagePath { get; set; } = "";
    public DateTime TakenOn { get; set; } = DateTime.Today;
    public int SortOrder { get; set; }
    public bool ShowOnHome { get; set; }
    public bool IsActive { get; set; } = true;
}

public class MenuItem : IEntity
{
    public int Id { get; set; }
    [MaxLength(60)] public string Section { get; set; } = "";
    [MaxLength(100)] public string Group { get; set; } = "";     // heading used by the mega menu
    [MaxLength(300)] public string Title { get; set; } = "";
    [MaxLength(500)] public string Url { get; set; } = "#";
    public int SortOrder { get; set; }
    public bool IsActive { get; set; } = true;
}

public class Complaint
{
    public int Id { get; set; }
    [MaxLength(30)] public string TicketNo { get; set; } = "";
    [MaxLength(100)] public string Name { get; set; } = "";
    [MaxLength(15)] public string Phone { get; set; } = "";
    [MaxLength(150)] public string Email { get; set; } = "";
    [MaxLength(100)] public string Category { get; set; } = "";
    [MaxLength(100)] public string Ward { get; set; } = "";
    [MaxLength(250)] public string Location { get; set; } = "";
    [MaxLength(2000)] public string Description { get; set; } = "";
    [MaxLength(20)] public string Status { get; set; } = "New";
    [MaxLength(1000)] public string AdminRemark { get; set; } = "";
    public DateTime CreatedOn { get; set; } = DateTime.Now;
    public DateTime UpdatedOn { get; set; } = DateTime.Now;
}

public class SiteSetting
{
    [Key, MaxLength(60)] public string Key { get; set; } = "";
    [MaxLength(500)] public string Value { get; set; } = "";
}

public class AuditLog
{
    public int Id { get; set; }
    public DateTime At { get; set; } = DateTime.Now;
    [MaxLength(50)] public string User { get; set; } = "";
    [MaxLength(50)] public string Action { get; set; } = "";
    [MaxLength(100)] public string Entity { get; set; } = "";
    [MaxLength(500)] public string Details { get; set; } = "";
}

/// <summary>Elected representatives and officials shown on /elected-wing, /administration and optionally the home page.</summary>
public class Person : IEntity
{
    public int Id { get; set; }
    [MaxLength(200)] public string Name { get; set; } = "";
    [MaxLength(20)] public string Category { get; set; } = "Elected";     // "Elected" | "Official"
    [MaxLength(200)] public string Designation { get; set; } = "";
    [MaxLength(200)] public string Department { get; set; } = "";
    [MaxLength(100)] public string WardOrZone { get; set; } = "";
    [MaxLength(100)] public string Party { get; set; } = "";
    [MaxLength(100)] public string Term { get; set; } = "";
    [MaxLength(300)] public string PhotoPath { get; set; } = "";
    [MaxLength(30)] public string Phone { get; set; } = "";
    [MaxLength(150)] public string Email { get; set; } = "";
    [MaxLength(300)] public string OfficeAddress { get; set; } = "";
    public string Bio { get; set; } = "";                                  // nvarchar(max)
    public int SortOrder { get; set; }
    public bool ShowOnHome { get; set; }
    public bool ShowContact { get; set; }                                  // phone/email public only if ticked
    public bool IsActive { get; set; } = true;
}
