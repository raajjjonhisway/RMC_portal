using System.Reflection;
using System.Text.RegularExpressions;
using Microsoft.EntityFrameworkCore;

namespace RanchiMunicipal.Data;

/// <summary>
/// Brings an existing database up to date at start-up (when Database:AutoCreate = true).
///
/// EF's EnsureCreated only creates tables when the database has NO tables at all. If the database already contains
/// anything (an earlier version of this site, a half-finished script run, other applications' tables), it does nothing
/// and the app then fails on missing tables or columns. So after EnsureCreated we also run the embedded, idempotent
/// Database/CreateDatabase.sql – every statement is "create only if missing" – which adds whatever is absent
/// (tables, new columns, indexes) and never drops or changes existing data.
/// </summary>
public static class SchemaUpgrade
{
    public static async Task ApplyAsync(AppDbContext db, ILogger? logger = null)
    {
        var asm = Assembly.GetExecutingAssembly();
        await using var stream = asm.GetManifestResourceStream("CreateDatabase.sql");
        if (stream == null)
        {
            logger?.LogWarning("Embedded CreateDatabase.sql not found – schema upgrade skipped.");
            return;
        }
        using var reader = new StreamReader(stream);
        var script = await reader.ReadToEndAsync();

        // Drop /* block comments */ first so a "GO" written inside a comment (the optional login example) is not treated as a separator.
        script = Regex.Replace(script, @"/\*.*?\*/", "", RegexOptions.Singleline);

        // Split on lines that contain only GO (SSMS / sqlcmd batch separator).
        var batches = Regex.Split(script, @"^\s*GO\s*$", RegexOptions.Multiline | RegexOptions.IgnoreCase);

        var conn = db.Database.GetDbConnection();
        var openedHere = conn.State != System.Data.ConnectionState.Open;
        if (openedHere) await conn.OpenAsync();
        try
        {
            foreach (var raw in batches)
            {
                var batch = raw.Trim();
                if (batch.Length == 0) continue;
                // The connection string already selects the database: skip the CREATE DATABASE / USE part of the script.
                if (batch.Contains("IF DB_ID(", StringComparison.OrdinalIgnoreCase)) continue;
                if (batch.StartsWith("USE ", StringComparison.OrdinalIgnoreCase)) continue;

                await using var cmd = conn.CreateCommand();
                cmd.CommandText = batch;
                cmd.CommandTimeout = 60;
                await cmd.ExecuteNonQueryAsync();
            }
        }
        finally
        {
            if (openedHere) await conn.CloseAsync();
        }
    }
}
