using Microsoft.EntityFrameworkCore;
using RanchiMunicipal.Services;

namespace RanchiMunicipal.Data;

/// <summary>Creates the database and fills it with SAMPLE content on first run. Replace the samples from the admin panel.</summary>
public static class Seeder
{
    public static async Task RunAsync(AppDbContext db, IConfiguration cfg, ILogger logger)
    {
        // Creates the database/tables when they are missing. Set Database:AutoCreate=false if you create them
        // yourself with Database/CreateDatabase.sql (the seeding below still runs and only fills empty tables).
        // EnsureCreated does nothing when the tables already exist.
        if (cfg.GetValue("Database:AutoCreate", true))
        {
            await db.Database.EnsureCreatedAsync();
            await SchemaUpgrade.ApplyAsync(db, logger);   // adds newer tables/columns to a database created by an earlier version
        }

        // ---- admin user ----
        if (!await db.AdminUsers.AnyAsync())
        {
            var username = cfg["Admin:InitialUsername"];
            if (string.IsNullOrWhiteSpace(username)) username = "admin";
            var password = cfg["Admin:InitialPassword"];
            var generated = string.IsNullOrWhiteSpace(password);
            if (generated) password = PasswordHelper.RandomPassword();

            db.AdminUsers.Add(new AdminUser
            {
                Username = username,
                DisplayName = "Administrator",
                PasswordHash = PasswordHelper.Hash(password!),
                MustChangePassword = true
            });
            await db.SaveChangesAsync();
            logger.LogWarning("FIRST RUN: admin user '{User}' created with password '{Pass}'. You must change it at first login.", username, password);
        }

        // ---- settings (add any missing keys) ----
        var existing = await db.Settings.Select(s => s.Key).ToListAsync();
        foreach (var def in SettingKeys.All.Where(d => !existing.Contains(d.Key)))
            db.Settings.Add(new SiteSetting { Key = def.Key, Value = def.Default });
        await db.SaveChangesAsync();

        if (!await db.Slides.AnyAsync())
        {
            db.Slides.AddRange(
                new Slide { Title = "Swachh Ranchi,", Subtitle = "Sundar Ranchi", Caption = "Segregate waste at source — dry and wet, every day.", Theme = "Ocean", LinkUrl = "/page/about-rmc", SortOrder = 1 },
                new Slide { Title = "Pay Property Tax", Subtitle = "Online, Anytime", Caption = "Quick, safe and paperless — pay from the comfort of your home.", Theme = "Royal", LinkUrl = "#", SortOrder = 2 },
                new Slide { Title = "Report a Civic Issue", Subtitle = "We Are Listening", Caption = "Use the RMC app, WhatsApp or the complaint form to register a complaint.", Theme = "Forest", LinkUrl = "/complaint", SortOrder = 3 });
        }

        if (!await db.News.AnyAsync())
        {
            var t = DateTime.Today;
            db.News.AddRange(
                new NewsItem { Tag = "Imp. News", Title = "Public notice regarding the property tax rebate scheme for the current financial year", Body = "<p>Sample notice. Replace this text from the admin panel.</p>", PublishedOn = t },
                new NewsItem { Tag = "Imp. News", Title = "To report any financial cybercrime call 1930 immediately or register at www.cybercrime.gov.in", Body = "<p>Sample notice.</p>", PublishedOn = t.AddDays(-1) },
                new NewsItem { Tag = "Quotation", Title = "Supply of electrical materials for street light maintenance in various wards", Body = "<p>Sample quotation notice.</p>", PublishedOn = t.AddDays(-2) },
                new NewsItem { Tag = "Quotation", Title = "Hiring of machinery for desilting of drains in the Central Zone", Body = "<p>Sample quotation notice.</p>", PublishedOn = t.AddDays(-3) },
                new NewsItem { Tag = "Tender", Title = "E-tender for construction and strengthening of roads within RMC limits", Body = "<p>Sample tender notice.</p>", PublishedOn = t.AddDays(-4) },
                new NewsItem { Tag = "Notice", Title = "Camp for Birth & Death certificate corrections at the RMC head office", Body = "<p>Sample notice.</p>", PublishedOn = t.AddDays(-5) },
                new NewsItem { Tag = "Recruitment", Title = "Applications invited for contractual posts in various departments of RMC", Body = "<p>Sample recruitment notice.</p>", PublishedOn = t.AddDays(-6) },
                new NewsItem { Tag = "Quotation", Title = "Supply of sanitation equipment and consumables for the Health Department", Body = "<p>Sample quotation notice.</p>", PublishedOn = t.AddDays(-7) });
        }

        if (!await db.Tenders.AnyAsync())
        {
            var t = DateTime.Today;
            db.Tenders.AddRange(
                new Tender { RefNo = "RMC/ENG/2026/001", Title = "Construction and strengthening of roads – Package 1", Department = "Engineering", PublishedOn = t.AddDays(-4), LastDate = t.AddDays(14) },
                new Tender { RefNo = "RMC/WS/2026/007", Title = "Supply of water meters", Department = "Water Supply", PublishedOn = t.AddDays(-20), LastDate = t.AddDays(-2) },
                new Tender { RefNo = "RMC/HLT/2026/012", Title = "Supply of sanitation equipment", Department = "Health & Sanitation", PublishedOn = t.AddDays(-1), LastDate = t.AddDays(20) });
        }

        if (!await db.Services.AnyAsync())
        {
            db.Services.AddRange(
                new ServiceCard { Title = "Virtual Civic Centre (Online Services)", Description = "Simple and convenient way to access RMC services from anywhere, anytime. Pay property tax, water bills and obtain birth and death certificates.", Icon = "bi-pc-display-horizontal", Theme = "Royal", Url = "#", SortOrder = 1 },
                new ServiceCard { Title = "Health & Medical Services", Description = "Information about urban primary health centres, immunisation drives, sanitation inspections and public health programmes.", Icon = "bi-hospital", Theme = "Sunset", Url = "#", SortOrder = 2 },
                new ServiceCard { Title = "Smart City Ranchi", Description = "Smart City projects including the integrated command and control centre, smart roads, lighting and e-governance.", Icon = "bi-buildings", Theme = "Forest", Url = "#", SortOrder = 3 },
                new ServiceCard { Title = "GIS Portal", Description = "View town planning, property tax and ward details visually on the map.", Icon = "bi-geo-alt", Theme = "Violet", Url = "#", SortOrder = 4 },
                new ServiceCard { Title = "Online Application Services", Description = "Apply online for trade licences, building plan approvals, marriage registration and other permissions.", Icon = "bi-file-earmark-text", Theme = "Sunset", Url = "#", SortOrder = 5 },
                new ServiceCard { Title = "Right to Information", Description = "Details of Public Information Officers, appellate authorities and how to file an RTI application with RMC.", Icon = "bi-info-circle", Theme = "Ocean", Url = "/page/rti", SortOrder = 6 },
                new ServiceCard { Title = "Property Tax", Description = "Know your property tax, view payment history, download receipts and pay online securely.", Icon = "bi-house-check", Theme = "Rose", Url = "#", SortOrder = 7 },
                new ServiceCard { Title = "Grievance Redressal", Description = "Register and track complaints through the website, app, WhatsApp or toll free number.", Icon = "bi-chat-dots", Theme = "Forest", Url = "/complaint", SortOrder = 8 });
        }

        if (!await db.QuickLinks.AnyAsync())
        {
            db.QuickLinks.AddRange(
                new QuickLink { Title = "Agenda", Icon = "bi-file-earmark-text", Url = "#", SortOrder = 1 },
                new QuickLink { Title = "Resolution", Icon = "bi-clipboard-check", Url = "#", SortOrder = 2 },
                new QuickLink { Title = "Recruitment", Icon = "bi-person-vcard", Url = "/news?tag=Recruitment", SortOrder = 3 },
                new QuickLink { Title = "News", Icon = "bi-newspaper", Url = "/news", SortOrder = 4 },
                new QuickLink { Title = "Tenders / Quotations", Icon = "bi-hammer", Url = "/tenders", SortOrder = 5 },
                new QuickLink { Title = "Town Planning", Icon = "bi-building-gear", Url = "#", SortOrder = 6 },
                new QuickLink { Title = "Budget", Icon = "bi-currency-rupee", Url = "#", SortOrder = 7 },
                new QuickLink { Title = "Elected Wing", Icon = "bi-people", Url = "/elected-wing", SortOrder = 8 });
        }

        if (!await db.Pages.AnyAsync())
        {
            const string sample = "<p>This is sample content. Edit it from <strong>Admin → Pages</strong>.</p>";
            db.Pages.AddRange(
                new ContentPage { Slug = "about-rmc", Title = "About Ranchi Municipal Corporation", Body = sample },
                new ContentPage { Slug = "citizen-charter", Title = "Citizen Charter", Body = sample },
                new ContentPage { Slug = "rti", Title = "Right to Information", Body = sample },
                new ContentPage { Slug = "rainfall-statistics", Title = "Rainfall Statistics", Body = sample },
                new ContentPage { Slug = "privacy-policy", Title = "Privacy Policy", Body = sample },
                new ContentPage { Slug = "terms", Title = "Terms & Conditions", Body = sample });
        }

        if (!await db.People.AnyAsync())
        {
            // Placeholders – replace them from Admin → Officials & elected.
            db.People.AddRange(
                new Person { Category = "Elected", Name = "[Mayor name]", Designation = "Mayor", SortOrder = 1, ShowOnHome = true, Bio = "<p>Sample profile. Edit from the admin panel.</p>" },
                new Person { Category = "Elected", Name = "[Deputy Mayor name]", Designation = "Deputy Mayor", SortOrder = 2, ShowOnHome = true },
                new Person { Category = "Official", Name = "[Municipal Commissioner name]", Designation = "Municipal Commissioner", Department = "Administration", SortOrder = 1, ShowOnHome = true },
                new Person { Category = "Official", Name = "[Deputy Municipal Commissioner name]", Designation = "Deputy Municipal Commissioner", Department = "Administration", SortOrder = 2 });
        }

        if (!await db.GalleryCategories.AnyAsync())
        {
            db.GalleryCategories.AddRange(
                new GalleryCategory { Name = "Events", SortOrder = 1 },
                new GalleryCategory { Name = "Infrastructure", SortOrder = 2 },
                new GalleryCategory { Name = "Swachh Bharat Drive", SortOrder = 3 },
                new GalleryCategory { Name = "Health Camps", SortOrder = 4 });
        }

        if (!await db.GalleryImages.AnyAsync())
        {
            // Placeholders – replace the images and captions from Admin → Gallery.
            db.GalleryImages.AddRange(
                new GalleryImage { Category = "Events", Title = "Republic Day celebrations at RMC", Caption = "Sample photo. Replace from the admin panel.", SortOrder = 1, ShowOnHome = true },
                new GalleryImage { Category = "Infrastructure", Title = "Road widening work, Main Road", Caption = "Sample photo.", SortOrder = 1, ShowOnHome = true },
                new GalleryImage { Category = "Swachh Bharat Drive", Title = "Ward-level cleanliness drive", Caption = "Sample photo.", SortOrder = 1, ShowOnHome = true },
                new GalleryImage { Category = "Health Camps", Title = "Free health check-up camp", Caption = "Sample photo.", SortOrder = 1, ShowOnHome = true });
        }

        if (!await db.MenuItems.AnyAsync())
        {
            var order = 0;
            // Group = column heading when the menu style is "Mega"; leave "" for a plain list.
            void M(string section, string group, string title, string url) =>
                db.MenuItems.Add(new MenuItem { Section = section, Group = group, Title = title, Url = url, SortOrder = ++order });

            M("The City", "Know Ranchi", "About Ranchi", "#"); M("The City", "Know Ranchi", "Places to Visit", "#"); M("The City", "Know Ranchi", "City Map", "#");

            M("Corporation", "About RMC", "About RMC", "/page/about-rmc"); M("Corporation", "About RMC", "Citizen Charter", "/page/citizen-charter");
            M("Corporation", "People", "Mayor & Deputy Mayor", "/elected-wing"); M("Corporation", "People", "Elected Wing", "/elected-wing");
            M("Corporation", "People", "Municipal Commissioner", "/administration"); M("Corporation", "People", "Administrative Wing", "/administration");
            M("Corporation", "Finance", "Budget", "#");

            M("Departments", "Public Health", "Health & Sanitation", "#");
            M("Departments", "Infrastructure", "Engineering", "#"); M("Departments", "Infrastructure", "Water Supply", "#"); M("Departments", "Infrastructure", "Town Planning", "#");
            M("Departments", "Revenue", "Revenue / Property Tax", "#");

            M("Zones", "Zones", "Zone 1", "#"); M("Zones", "Zones", "Zone 2", "#"); M("Zones", "Zones", "Zone 3", "#");

            M("Services", "Pay & Apply", "Property Tax", "#"); M("Services", "Pay & Apply", "Water Bill", "#"); M("Services", "Pay & Apply", "Birth / Death Certificate", "#");
            M("Services", "Complaints", "Lodge a Complaint", "/complaint"); M("Services", "Complaints", "Track Complaint", "/complaint/track");

            M("Information", "Citizens", "Right to Information", "/page/rti"); M("Information", "Citizens", "Citizen Charter", "/page/citizen-charter");
            M("Information", "Notices", "Tenders / Quotations", "/tenders"); M("Information", "Notices", "News & Notices", "/news");
            M("Information", "Notices", "Photo Gallery", "/gallery");

            M("Downloads", "Downloads", "Forms", "#"); M("Downloads", "Downloads", "Government Orders", "#"); M("Downloads", "Downloads", "Reports", "#");
            M("FAQs", "FAQs", "General FAQs", "#");

            M(MenuSectionsApps, "", "RMC Citizen App (Android)", "#");
            M(MenuSectionsSites, "", "Smart City Ranchi", "#"); M(MenuSectionsSites, "", "Government of Jharkhand", "https://www.jharkhand.gov.in");
            M(MenuSectionsOnline, "", "Pay Property Tax", "#"); M(MenuSectionsOnline, "", "Lodge a Complaint", "/complaint"); M(MenuSectionsOnline, "", "Track Complaint", "/complaint/track");
        }

        await db.SaveChangesAsync();
    }

    private const string MenuSectionsApps = Models.MenuSections.Apps;
    private const string MenuSectionsSites = Models.MenuSections.Sites;
    private const string MenuSectionsOnline = Models.MenuSections.Online;
}
