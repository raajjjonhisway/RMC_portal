using RanchiMunicipal.Models;

namespace RanchiMunicipal.Data;

public record SettingDef(string Key, string Label, string Default, string Group, FieldType Type = FieldType.Text, string[]? Options = null);

public static class SettingKeys
{
    public static readonly SettingDef[] All =
    {
        new("MenuStyle", "Main menu style", "Mega", "Appearance", FieldType.Select, new[] { "Mega", "Normal" }),
        new("HomeDesign", "Website design", "New", "Appearance", FieldType.Select, new[] { "New", "Previous" }),
        new("AdminDesign", "Admin panel design", "New", "Appearance", FieldType.Select, new[] { "New", "Previous" }),

        new("NameEn", "Corporation name (English)", "Ranchi Municipal Corporation", "Identity"),
        new("NameHi", "Corporation name (Hindi)", "रांची नगर निगम", "Identity"),
        new("Tagline", "Tagline", "Together for a cleaner, greener and smarter Ranchi", "Identity"),
        new("Ticker", "Banner strip under the hero", "Together for a cleaner, greener and smarter Ranchi", "Identity"),

        new("TollFree", "Toll free number", "1800 000 0000", "Contact"),
        new("WhatsApp", "WhatsApp number", "00000 00000", "Contact"),
        new("Email", "Email", "info@ranchimunicipal.example", "Contact"),
        new("Address", "Address", "Ranchi Municipal Corporation, Ranchi, Jharkhand", "Contact", FieldType.TextArea),

        new("MobileAppUrl", "Mobile app link", "#", "Links", FieldType.Url),
        new("SmartCityUrl", "Smart City Mission link", "#", "Links", FieldType.Url),
        new("SwachhUrl", "Swachh Bharat Mission link", "#", "Links", FieldType.Url),
        new("Facebook", "Facebook", "#", "Social", FieldType.Url),
        new("Twitter", "X (Twitter)", "#", "Social", FieldType.Url),
        new("Instagram", "Instagram", "#", "Social", FieldType.Url),
        new("YouTube", "YouTube", "#", "Social", FieldType.Url),
    };

    public static string Default(string key) => All.FirstOrDefault(s => s.Key == key)?.Default ?? "";
}
