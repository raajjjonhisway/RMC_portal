/* =====================================================================
   Ranchi Municipal Corporation – SQL Server schema
   Safe to run more than once (every object is created only if missing).

   How to use
   1. Open in SSMS / Azure Data Studio / sqlcmd as a login that may create databases.
   2. Run the whole script  (sqlcmd -S localhost -E -i CreateDatabase.sql).
   3. In appsettings.json set  "Database": { "AutoCreate": false }.
   4. Start the site. On first run it fills the empty tables with sample content, creates the
      admin user and prints its one-time password in the console. (No password is stored in this script.)

   Column types/sizes mirror Data/Entities.cs – keep both in sync when you change one.
   ===================================================================== */

IF DB_ID(N'RanchiMunicipal') IS NULL
    CREATE DATABASE [RanchiMunicipal];
GO

USE [RanchiMunicipal];
GO

/* ---------- Admin users ---------- */
IF OBJECT_ID(N'dbo.AdminUsers', N'U') IS NULL
CREATE TABLE dbo.AdminUsers
(
    Id                  int IDENTITY(1,1) NOT NULL CONSTRAINT PK_AdminUsers PRIMARY KEY,
    Username            nvarchar(50)  NOT NULL,
    PasswordHash        nvarchar(200) NOT NULL,
    DisplayName         nvarchar(100) NOT NULL CONSTRAINT DF_AdminUsers_DisplayName DEFAULT (N''),
    MustChangePassword  bit           NOT NULL CONSTRAINT DF_AdminUsers_MustChange DEFAULT (1),
    IsActive            bit           NOT NULL CONSTRAINT DF_AdminUsers_IsActive DEFAULT (1),
    CreatedOn           datetime2(7)  NOT NULL CONSTRAINT DF_AdminUsers_CreatedOn DEFAULT (SYSDATETIME()),
    LastLoginOn         datetime2(7)  NULL
);
GO
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = N'IX_AdminUsers_Username' AND object_id = OBJECT_ID(N'dbo.AdminUsers'))
    CREATE UNIQUE INDEX IX_AdminUsers_Username ON dbo.AdminUsers (Username);
GO

/* ---------- Hero slides ---------- */
IF OBJECT_ID(N'dbo.Slides', N'U') IS NULL
CREATE TABLE dbo.Slides
(
    Id         int IDENTITY(1,1) NOT NULL CONSTRAINT PK_Slides PRIMARY KEY,
    Title      nvarchar(300)  NOT NULL,
    Subtitle   nvarchar(300)  NOT NULL CONSTRAINT DF_Slides_Subtitle DEFAULT (N''),
    Caption    nvarchar(4000) NOT NULL CONSTRAINT DF_Slides_Caption DEFAULT (N''),
    Theme      nvarchar(30)   NOT NULL CONSTRAINT DF_Slides_Theme DEFAULT (N'Ocean'),
    ImagePath  nvarchar(300)  NOT NULL CONSTRAINT DF_Slides_ImagePath DEFAULT (N''),
    LinkUrl    nvarchar(500)  NOT NULL CONSTRAINT DF_Slides_LinkUrl DEFAULT (N''),
    SortOrder  int            NOT NULL CONSTRAINT DF_Slides_SortOrder DEFAULT (0),
    IsActive   bit            NOT NULL CONSTRAINT DF_Slides_IsActive DEFAULT (1)
);
GO

/* ---------- News & notices ---------- */
IF OBJECT_ID(N'dbo.News', N'U') IS NULL
CREATE TABLE dbo.News
(
    Id              int IDENTITY(1,1) NOT NULL CONSTRAINT PK_News PRIMARY KEY,
    Tag             nvarchar(30)  NOT NULL CONSTRAINT DF_News_Tag DEFAULT (N'Notice'),
    Title           nvarchar(300) NOT NULL,
    Body            nvarchar(max) NOT NULL CONSTRAINT DF_News_Body DEFAULT (N''),
    PublishedOn     datetime2(7)  NOT NULL CONSTRAINT DF_News_PublishedOn DEFAULT (CONVERT(date, SYSDATETIME())),
    AttachmentPath  nvarchar(300) NOT NULL CONSTRAINT DF_News_Attachment DEFAULT (N''),
    LinkUrl         nvarchar(500) NOT NULL CONSTRAINT DF_News_LinkUrl DEFAULT (N''),
    IsActive        bit           NOT NULL CONSTRAINT DF_News_IsActive DEFAULT (1)
);
GO
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = N'IX_News_IsActive_PublishedOn' AND object_id = OBJECT_ID(N'dbo.News'))
    CREATE INDEX IX_News_IsActive_PublishedOn ON dbo.News (IsActive, PublishedOn);
GO

/* ---------- Tenders / quotations ---------- */
IF OBJECT_ID(N'dbo.Tenders', N'U') IS NULL
CREATE TABLE dbo.Tenders
(
    Id            int IDENTITY(1,1) NOT NULL CONSTRAINT PK_Tenders PRIMARY KEY,
    RefNo         nvarchar(300) NOT NULL,
    Title         nvarchar(300) NOT NULL,
    Department    nvarchar(300) NOT NULL CONSTRAINT DF_Tenders_Department DEFAULT (N''),
    PublishedOn   datetime2(7)  NOT NULL CONSTRAINT DF_Tenders_PublishedOn DEFAULT (CONVERT(date, SYSDATETIME())),
    LastDate      datetime2(7)  NOT NULL,
    DocumentPath  nvarchar(300) NOT NULL CONSTRAINT DF_Tenders_Document DEFAULT (N''),
    IsActive      bit           NOT NULL CONSTRAINT DF_Tenders_IsActive DEFAULT (1)
);
GO
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = N'IX_Tenders_LastDate' AND object_id = OBJECT_ID(N'dbo.Tenders'))
    CREATE INDEX IX_Tenders_LastDate ON dbo.Tenders (LastDate);
GO

/* ---------- CMS pages ---------- */
IF OBJECT_ID(N'dbo.Pages', N'U') IS NULL
CREATE TABLE dbo.Pages
(
    Id           int IDENTITY(1,1) NOT NULL CONSTRAINT PK_Pages PRIMARY KEY,
    Slug         nvarchar(60)  NOT NULL,
    Title        nvarchar(300) NOT NULL,
    Body         nvarchar(max) NOT NULL CONSTRAINT DF_Pages_Body DEFAULT (N''),
    IsPublished  bit           NOT NULL CONSTRAINT DF_Pages_IsPublished DEFAULT (1),
    UpdatedOn    datetime2(7)  NOT NULL CONSTRAINT DF_Pages_UpdatedOn DEFAULT (SYSDATETIME())
);
GO
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = N'IX_Pages_Slug' AND object_id = OBJECT_ID(N'dbo.Pages'))
    CREATE UNIQUE INDEX IX_Pages_Slug ON dbo.Pages (Slug);
GO

/* ---------- Home page service cards ---------- */
IF OBJECT_ID(N'dbo.Services', N'U') IS NULL
CREATE TABLE dbo.Services
(
    Id           int IDENTITY(1,1) NOT NULL CONSTRAINT PK_Services PRIMARY KEY,
    Title        nvarchar(300)  NOT NULL,
    Description  nvarchar(4000) NOT NULL CONSTRAINT DF_Services_Description DEFAULT (N''),
    Icon         nvarchar(300)  NOT NULL CONSTRAINT DF_Services_Icon DEFAULT (N'bi-info-circle'),
    Theme        nvarchar(30)   NOT NULL CONSTRAINT DF_Services_Theme DEFAULT (N'Ocean'),
    ImagePath    nvarchar(300)  NOT NULL CONSTRAINT DF_Services_ImagePath DEFAULT (N''),
    Url          nvarchar(500)  NOT NULL CONSTRAINT DF_Services_Url DEFAULT (N''),
    SortOrder    int            NOT NULL CONSTRAINT DF_Services_SortOrder DEFAULT (0),
    IsActive     bit            NOT NULL CONSTRAINT DF_Services_IsActive DEFAULT (1)
);
GO

/* ---------- Quick links (blue tiles) ---------- */
IF OBJECT_ID(N'dbo.QuickLinks', N'U') IS NULL
CREATE TABLE dbo.QuickLinks
(
    Id         int IDENTITY(1,1) NOT NULL CONSTRAINT PK_QuickLinks PRIMARY KEY,
    Title      nvarchar(300) NOT NULL,
    Icon       nvarchar(300) NOT NULL CONSTRAINT DF_QuickLinks_Icon DEFAULT (N'bi-link-45deg'),
    Url        nvarchar(500) NOT NULL CONSTRAINT DF_QuickLinks_Url DEFAULT (N''),
    SortOrder  int           NOT NULL CONSTRAINT DF_QuickLinks_SortOrder DEFAULT (0),
    IsActive   bit           NOT NULL CONSTRAINT DF_QuickLinks_IsActive DEFAULT (1)
);
GO

/* ---------- Menu items (all dropdowns) ---------- */
IF OBJECT_ID(N'dbo.MenuItems', N'U') IS NULL
CREATE TABLE dbo.MenuItems
(
    Id         int IDENTITY(1,1) NOT NULL CONSTRAINT PK_MenuItems PRIMARY KEY,
    Section    nvarchar(60)  NOT NULL,
    [Group]    nvarchar(100) NOT NULL CONSTRAINT DF_MenuItems_Group DEFAULT (N''),   -- column heading in the mega menu
    Title      nvarchar(300) NOT NULL,
    Url        nvarchar(500) NOT NULL CONSTRAINT DF_MenuItems_Url DEFAULT (N'#'),
    SortOrder  int           NOT NULL CONSTRAINT DF_MenuItems_SortOrder DEFAULT (0),
    IsActive   bit           NOT NULL CONSTRAINT DF_MenuItems_IsActive DEFAULT (1)
);
GO
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = N'IX_MenuItems_Section_SortOrder' AND object_id = OBJECT_ID(N'dbo.MenuItems'))
    CREATE INDEX IX_MenuItems_Section_SortOrder ON dbo.MenuItems (Section, SortOrder);
GO

/* ---------- Existing database from an earlier version? Add the newer column. ---------- */
IF COL_LENGTH(N'dbo.MenuItems', N'Group') IS NULL
    ALTER TABLE dbo.MenuItems ADD [Group] nvarchar(100) NOT NULL CONSTRAINT DF_MenuItems_Group DEFAULT (N'');
GO

/* ---------- Elected representatives and officials ---------- */
IF OBJECT_ID(N'dbo.People', N'U') IS NULL
CREATE TABLE dbo.People
(
    Id             int IDENTITY(1,1) NOT NULL CONSTRAINT PK_People PRIMARY KEY,
    Name           nvarchar(200) NOT NULL,
    Category       nvarchar(20)  NOT NULL CONSTRAINT DF_People_Category DEFAULT (N'Elected'),   -- Elected | Official
    Designation    nvarchar(200) NOT NULL CONSTRAINT DF_People_Designation DEFAULT (N''),
    Department     nvarchar(200) NOT NULL CONSTRAINT DF_People_Department DEFAULT (N''),
    WardOrZone     nvarchar(100) NOT NULL CONSTRAINT DF_People_Ward DEFAULT (N''),
    Party          nvarchar(100) NOT NULL CONSTRAINT DF_People_Party DEFAULT (N''),
    Term           nvarchar(100) NOT NULL CONSTRAINT DF_People_Term DEFAULT (N''),
    PhotoPath      nvarchar(300) NOT NULL CONSTRAINT DF_People_Photo DEFAULT (N''),
    Phone          nvarchar(30)  NOT NULL CONSTRAINT DF_People_Phone DEFAULT (N''),
    Email          nvarchar(150) NOT NULL CONSTRAINT DF_People_Email DEFAULT (N''),
    OfficeAddress  nvarchar(300) NOT NULL CONSTRAINT DF_People_Office DEFAULT (N''),
    Bio            nvarchar(max) NOT NULL CONSTRAINT DF_People_Bio DEFAULT (N''),
    SortOrder      int           NOT NULL CONSTRAINT DF_People_SortOrder DEFAULT (0),
    ShowOnHome     bit           NOT NULL CONSTRAINT DF_People_ShowOnHome DEFAULT (0),
    ShowContact    bit           NOT NULL CONSTRAINT DF_People_ShowContact DEFAULT (0),   -- phone/email public only if 1
    IsActive       bit           NOT NULL CONSTRAINT DF_People_IsActive DEFAULT (1)
);
GO
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = N'IX_People_Category_IsActive_SortOrder' AND object_id = OBJECT_ID(N'dbo.People'))
    CREATE INDEX IX_People_Category_IsActive_SortOrder ON dbo.People (Category, IsActive, SortOrder);
GO

/* ---------- Photo gallery categories ---------- */
IF OBJECT_ID(N'dbo.GalleryCategories', N'U') IS NULL
CREATE TABLE dbo.GalleryCategories
(
    Id         int IDENTITY(1,1) NOT NULL CONSTRAINT PK_GalleryCategories PRIMARY KEY,
    Name       nvarchar(100) NOT NULL,
    SortOrder  int           NOT NULL CONSTRAINT DF_GalleryCategories_SortOrder DEFAULT (0),
    IsActive   bit           NOT NULL CONSTRAINT DF_GalleryCategories_IsActive DEFAULT (1)
);
GO
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = N'IX_GalleryCategories_Name' AND object_id = OBJECT_ID(N'dbo.GalleryCategories'))
    CREATE UNIQUE INDEX IX_GalleryCategories_Name ON dbo.GalleryCategories (Name);
GO

/* ---------- Photo gallery images ---------- */
IF OBJECT_ID(N'dbo.GalleryImages', N'U') IS NULL
CREATE TABLE dbo.GalleryImages
(
    Id          int IDENTITY(1,1) NOT NULL CONSTRAINT PK_GalleryImages PRIMARY KEY,
    Category    nvarchar(100) NOT NULL CONSTRAINT DF_GalleryImages_Category DEFAULT (N''),
    Title       nvarchar(300) NOT NULL CONSTRAINT DF_GalleryImages_Title DEFAULT (N''),
    Caption     nvarchar(500) NOT NULL CONSTRAINT DF_GalleryImages_Caption DEFAULT (N''),
    ImagePath   nvarchar(300) NOT NULL CONSTRAINT DF_GalleryImages_ImagePath DEFAULT (N''),
    TakenOn     datetime2(7)  NOT NULL CONSTRAINT DF_GalleryImages_TakenOn DEFAULT (CONVERT(date, SYSDATETIME())),
    SortOrder   int           NOT NULL CONSTRAINT DF_GalleryImages_SortOrder DEFAULT (0),
    ShowOnHome  bit           NOT NULL CONSTRAINT DF_GalleryImages_ShowOnHome DEFAULT (0),
    IsActive    bit           NOT NULL CONSTRAINT DF_GalleryImages_IsActive DEFAULT (1)
);
GO
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = N'IX_GalleryImages_Category_IsActive_SortOrder' AND object_id = OBJECT_ID(N'dbo.GalleryImages'))
    CREATE INDEX IX_GalleryImages_Category_IsActive_SortOrder ON dbo.GalleryImages (Category, IsActive, SortOrder);
GO

/* ---------- Existing database from an earlier version? Add the newer AdminUsers columns. ---------- */
IF COL_LENGTH(N'dbo.AdminUsers', N'IsActive') IS NULL
    ALTER TABLE dbo.AdminUsers ADD IsActive bit NOT NULL CONSTRAINT DF_AdminUsers_IsActive DEFAULT (1);
GO
IF COL_LENGTH(N'dbo.AdminUsers', N'CreatedOn') IS NULL
    ALTER TABLE dbo.AdminUsers ADD CreatedOn datetime2(7) NOT NULL CONSTRAINT DF_AdminUsers_CreatedOn DEFAULT (SYSDATETIME());
GO
IF COL_LENGTH(N'dbo.AdminUsers', N'LastLoginOn') IS NULL
    ALTER TABLE dbo.AdminUsers ADD LastLoginOn datetime2(7) NULL;
GO

/* ---------- Citizen complaints ---------- */
IF OBJECT_ID(N'dbo.Complaints', N'U') IS NULL
CREATE TABLE dbo.Complaints
(
    Id           int IDENTITY(1,1) NOT NULL CONSTRAINT PK_Complaints PRIMARY KEY,
    TicketNo     nvarchar(30)   NOT NULL,
    Name         nvarchar(100)  NOT NULL,
    Phone        nvarchar(15)   NOT NULL,
    Email        nvarchar(150)  NOT NULL CONSTRAINT DF_Complaints_Email DEFAULT (N''),
    Category     nvarchar(100)  NOT NULL,
    Ward         nvarchar(100)  NOT NULL CONSTRAINT DF_Complaints_Ward DEFAULT (N''),
    Location     nvarchar(250)  NOT NULL CONSTRAINT DF_Complaints_Location DEFAULT (N''),
    Description  nvarchar(2000) NOT NULL,
    Status       nvarchar(20)   NOT NULL CONSTRAINT DF_Complaints_Status DEFAULT (N'New'),
    AdminRemark  nvarchar(1000) NOT NULL CONSTRAINT DF_Complaints_Remark DEFAULT (N''),
    CreatedOn    datetime2(7)   NOT NULL CONSTRAINT DF_Complaints_CreatedOn DEFAULT (SYSDATETIME()),
    UpdatedOn    datetime2(7)   NOT NULL CONSTRAINT DF_Complaints_UpdatedOn DEFAULT (SYSDATETIME())
);
GO
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = N'IX_Complaints_TicketNo' AND object_id = OBJECT_ID(N'dbo.Complaints'))
    CREATE UNIQUE INDEX IX_Complaints_TicketNo ON dbo.Complaints (TicketNo);
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = N'IX_Complaints_Status_CreatedOn' AND object_id = OBJECT_ID(N'dbo.Complaints'))
    CREATE INDEX IX_Complaints_Status_CreatedOn ON dbo.Complaints (Status, CreatedOn);
GO

/* ---------- Site settings (key / value) ---------- */
IF OBJECT_ID(N'dbo.Settings', N'U') IS NULL
CREATE TABLE dbo.Settings
(
    [Key]    nvarchar(60)  NOT NULL CONSTRAINT PK_Settings PRIMARY KEY,
    [Value]  nvarchar(500) NOT NULL CONSTRAINT DF_Settings_Value DEFAULT (N'')
);
GO

/* ---------- Admin activity log ---------- */
IF OBJECT_ID(N'dbo.AuditLogs', N'U') IS NULL
CREATE TABLE dbo.AuditLogs
(
    Id       int IDENTITY(1,1) NOT NULL CONSTRAINT PK_AuditLogs PRIMARY KEY,
    [At]     datetime2(7)  NOT NULL CONSTRAINT DF_AuditLogs_At DEFAULT (SYSDATETIME()),
    [User]   nvarchar(50)  NOT NULL,
    [Action] nvarchar(50)  NOT NULL,
    Entity   nvarchar(100) NOT NULL,
    Details  nvarchar(500) NOT NULL CONSTRAINT DF_AuditLogs_Details DEFAULT (N'')
);
GO

/* =====================================================================
   OPTIONAL – least-privilege login for the web application.
   Replace the password, then un-comment and run. Prefer storing the password in
   user-secrets / environment variables rather than appsettings.json.

   USE [master];
   CREATE LOGIN [rmc_app] WITH PASSWORD = N'CHANGE_ME_to_a_long_random_password', CHECK_POLICY = ON;
   GO
   USE [RanchiMunicipal];
   CREATE USER [rmc_app] FOR LOGIN [rmc_app];
   ALTER ROLE db_datareader ADD MEMBER [rmc_app];
   ALTER ROLE db_datawriter ADD MEMBER [rmc_app];
   GO

   Connection string for that login:
   Server=YOUR_SERVER;Database=RanchiMunicipal;User Id=rmc_app;Password=...;TrustServerCertificate=True;
   (With AutoCreate=false the app needs no DDL rights.)
   ===================================================================== */

PRINT N'RanchiMunicipal schema is ready.';
GO
