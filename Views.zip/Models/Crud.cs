namespace RanchiMunicipal.Models;

public enum FieldType { Text, TextArea, Html, Date, Number, Check, Select, File, Image, Url, Icon }

public record FieldDef(
    string Prop,
    string Label,
    FieldType Type = FieldType.Text,
    bool Required = false,
    bool InList = false,
    string[]? Options = null,
    string? Help = null,
    int MaxLength = 0)
{
    public int Max => MaxLength > 0 ? MaxLength : Type switch
    {
        FieldType.TextArea => 4000,
        FieldType.Html => 100000,
        FieldType.Url => 500,
        _ => 300
    };
}

public class FieldVm
{
    public required FieldDef Def { get; init; }
    public string Value { get; set; } = "";
    public string? Error { get; set; }
}

public class CrudRow
{
    public int Id { get; init; }
    public List<string> Cells { get; init; } = new();
}

public class CrudListVm
{
    public required string Title { get; init; }
    public required string Slug { get; init; }
    public required string Icon { get; init; }
    public required List<FieldDef> Columns { get; init; }
    public required List<CrudRow> Rows { get; init; }
    public string? Q { get; init; }
}

public class CrudEditVm
{
    public required string Title { get; init; }
    public required string Slug { get; init; }
    public int Id { get; init; }
    public bool IsNew { get; init; }
    public required List<FieldVm> Fields { get; init; }
    public string? Error { get; set; }
}
