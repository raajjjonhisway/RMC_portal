using System.ComponentModel.DataAnnotations;
using RanchiMunicipal.Data;

namespace RanchiMunicipal.Models;

public record SiteInfo(
    string NameEn, string NameHi, string Tagline, string TollFree, string WhatsApp, string Email, string Address,
    string MobileAppUrl, string Facebook, string Twitter, string Instagram, string YouTube,
    string Ticker, string SmartCityUrl, string SwachhUrl,
    string MenuStyle, string HomeDesign, string AdminDesign);

public static class MenuSections
{
    public const string Apps = "Our Mobile Apps";
    public const string Sites = "Our Websites";
    public const string Online = "Online Services";

    public static readonly (string Title, string Css)[] Main =
    {
        ("The City", "nav-city"), ("Corporation", "nav-corp"), ("Departments", "nav-dept"), ("Zones", "nav-zone"),
        ("Services", "nav-serv"), ("Information", "nav-info"), ("Downloads", "nav-down"), ("FAQs", "nav-faq")
    };

    public static string[] All => Main.Select(m => m.Title).Concat(new[] { Apps, Sites, Online }).ToArray();
}

public record NavSection(string Title, string CssClass, IReadOnlyList<MenuItem> Items);

public class NavModel
{
    public required IReadOnlyList<NavSection> Main { get; init; }
    public required IReadOnlyList<MenuItem> MobileApps { get; init; }
    public required IReadOnlyList<MenuItem> Websites { get; init; }
    public required IReadOnlyList<MenuItem> Online { get; init; }
}

public record MainNavVm(NavModel Nav, bool Mega);

public record ComplaintChannel(string Label, string Value, string Icon, string Url, string IconColor);

public class HomeViewModel
{
    public required SiteInfo Site { get; init; }
    public required IReadOnlyList<Slide> Slides { get; init; }
    public required IReadOnlyList<NewsItem> News { get; init; }
    public required IReadOnlyList<ServiceCard> Services { get; init; }
    public required IReadOnlyList<QuickLink> QuickLinks { get; init; }
    public required IReadOnlyList<Person> Leaders { get; init; }
    public required IReadOnlyList<GalleryImage> GalleryPreview { get; init; }
    public required IReadOnlyList<ComplaintChannel> Channels { get; init; }
}

public class PagerVm
{
    public int Page { get; init; }
    public int TotalPages { get; init; }
    /// <summary>URL prefix ending in "page=" (already encoded); the page number is appended.</summary>
    public required string BaseUrl { get; init; }
}

public class ListVm<T>
{
    public required IReadOnlyList<T> Items { get; init; }
    public int Page { get; init; }
    public int PageSize { get; init; }
    public int Total { get; init; }
    public int TotalPages => Math.Max(1, (int)Math.Ceiling(Total / (double)PageSize));
}

public class SearchVm
{
    public string Q { get; init; } = "";
    public IReadOnlyList<NewsItem> News { get; init; } = Array.Empty<NewsItem>();
    public IReadOnlyList<Tender> Tenders { get; init; } = Array.Empty<Tender>();
    public IReadOnlyList<ContentPage> Pages { get; init; } = Array.Empty<ContentPage>();
}

public static class Lookups
{
    public static readonly string[] NewsTags = { "Imp. News", "Quotation", "Tender", "Recruitment", "Notice", "Press Release" };
    public static readonly string[] PersonCategories = { "Elected", "Official" };
    public static readonly string[] Themes = { "Ocean", "Royal", "Forest", "Sunset", "Violet", "Rose" };
    public static readonly string[] ComplaintStatuses = { "New", "In Progress", "Resolved", "Rejected" };
    public static readonly string[] ComplaintCategories =
    {
        "Water Supply", "Drainage & Sewerage", "Garbage / Sanitation", "Street Light", "Roads & Potholes",
        "Property Tax", "Encroachment", "Birth / Death Certificate", "Other"
    };
    public static readonly string[] Icons =
    {
        "bi-pc-display-horizontal", "bi-hospital", "bi-buildings", "bi-geo-alt", "bi-file-earmark-text", "bi-info-circle",
        "bi-house-check", "bi-chat-dots", "bi-droplet", "bi-lightbulb", "bi-recycle", "bi-people", "bi-newspaper",
        "bi-hammer", "bi-currency-rupee", "bi-clipboard-check", "bi-person-vcard", "bi-building-gear", "bi-cpu", "bi-globe2"
    };

    public static string TagCss(string tag) => tag switch
    {
        "Imp. News" => "tag-imp", "Recruitment" => "tag-rec", "Tender" => "tag-tender",
        "Notice" => "tag-notice", "Press Release" => "tag-press", _ => "tag-quote"
    };

    public static bool IsExternal(string? url) => url != null && url.StartsWith("http", StringComparison.OrdinalIgnoreCase);

    /// <summary>
    /// Builds a LIKE pattern (escape char is backslash) so user input cannot inject wildcards.
    /// "[" is escaped too because SQL Server treats [abc] as a character-class wildcard.
    /// </summary>
    public static string Like(string q) =>
        "%" + q.Replace("\\", "\\\\").Replace("%", "\\%").Replace("_", "\\_").Replace("[", "\\[") + "%";

    /// <summary>True for links that are safe to place in an href (blocks javascript:, data:, etc.).</summary>
    public static bool IsSafeUrl(string? url)
    {
        if (string.IsNullOrWhiteSpace(url)) return true;
        url = url.Trim();
        if (url.StartsWith("//")) return false;
        return url.StartsWith('/') || url.StartsWith('#') ||
               url.StartsWith("http://", StringComparison.OrdinalIgnoreCase) ||
               url.StartsWith("https://", StringComparison.OrdinalIgnoreCase) ||
               url.StartsWith("tel:", StringComparison.OrdinalIgnoreCase) ||
               url.StartsWith("mailto:", StringComparison.OrdinalIgnoreCase);
    }
}

public class ComplaintForm
{
    [Required, StringLength(100)] public string Name { get; set; } = "";
    [Required, RegularExpression(@"^[6-9]\d{9}$", ErrorMessage = "Enter a valid 10-digit mobile number.")]
    public string Phone { get; set; } = "";
    [EmailAddress, StringLength(150)] public string? Email { get; set; }
    [Required] public string Category { get; set; } = "";
    [StringLength(100)] public string? Ward { get; set; }
    [StringLength(250)] public string? Location { get; set; }
    [Required, StringLength(2000, MinimumLength = 10)] public string Description { get; set; } = "";
    /// <summary>Honeypot – must stay empty.</summary>
    public string? Website { get; set; }
}

public class TrackForm
{
    [Required] public string Ticket { get; set; } = "";
    [Required] public string Phone { get; set; } = "";
}

public class LoginVm
{
    [Required] public string Username { get; set; } = "";
    [Required, DataType(DataType.Password)] public string Password { get; set; } = "";
    public string? ReturnUrl { get; set; }
}

public class ChangePasswordVm
{
    [Required, DataType(DataType.Password)] public string Current { get; set; } = "";
    [Required, MinLength(10, ErrorMessage = "Use at least 10 characters."), DataType(DataType.Password)]
    public string New { get; set; } = "";
    [Required, Compare(nameof(New), ErrorMessage = "Passwords do not match."), DataType(DataType.Password)]
    public string Confirm { get; set; } = "";
}

public class AdminUserRowVm
{
    public int Id { get; init; }
    public string Username { get; init; } = "";
    public string DisplayName { get; init; } = "";
    public bool IsActive { get; init; }
    public bool MustChangePassword { get; init; }
    public DateTime CreatedOn { get; init; }
    public DateTime? LastLoginOn { get; init; }
    public bool IsSelf { get; init; }
}

public class AdminUserFormVm
{
    public int Id { get; set; }
    public bool IsNew { get; set; }
    public bool IsSelf { get; set; }

    [Required, StringLength(50, MinimumLength = 3), RegularExpression("^[a-zA-Z0-9._-]+$", ErrorMessage = "Letters, digits, dot, underscore and hyphen only.")]
    public string Username { get; set; } = "";
    [StringLength(100)] public string DisplayName { get; set; } = "";
    public bool IsActive { get; set; } = true;

    /// <summary>Leave blank on Edit to keep the current password unchanged.</summary>
    [DataType(DataType.Password)] public string? NewPassword { get; set; }
    [DataType(DataType.Password), Compare(nameof(NewPassword), ErrorMessage = "Passwords do not match.")] public string? ConfirmPassword { get; set; }
    public bool MustChangePassword { get; set; } = true;

    public string? Error { get; set; }
}

public class DashboardVm
{
    public int News { get; init; }
    public int OpenTenders { get; init; }
    public int Pages { get; init; }
    public int Total { get; init; }
    public int New { get; init; }
    public int InProgress { get; init; }
    public int Resolved { get; init; }
    public required List<KeyValuePair<string, int>> ByCategory { get; init; }
    public required List<Complaint> Recent { get; init; }
    public required List<AuditLog> Activity { get; init; }
}
