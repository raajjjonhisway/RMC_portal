using RanchiMunicipal.Data;

namespace RanchiMunicipal.Services;

public interface IAuditService
{
    Task LogAsync(string action, string entity, string? details = null);
}

public class AuditService : IAuditService
{
    private readonly AppDbContext _db;
    private readonly IHttpContextAccessor _http;

    public AuditService(AppDbContext db, IHttpContextAccessor http)
    {
        _db = db;
        _http = http;
    }

    public async Task LogAsync(string action, string entity, string? details = null)
    {
        var user = _http.HttpContext?.User?.Identity?.Name ?? "system";
        _db.AuditLogs.Add(new AuditLog
        {
            User = Cut(user, 50), Action = Cut(action, 50), Entity = Cut(entity, 100), Details = Cut(details ?? "", 500)
        });
        await _db.SaveChangesAsync();
    }

    // Column sizes are fixed on SQL Server – never let a long label make the audit insert fail.
    private static string Cut(string s, int max) => s.Length <= max ? s : s[..max];
}
