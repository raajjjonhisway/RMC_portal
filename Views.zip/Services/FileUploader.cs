namespace RanchiMunicipal.Services;

public interface IFileUploader
{
    Task<(string? Path, string? Error)> SaveAsync(IFormFile file, bool imageOnly);
    void Delete(string? path);
}

public class FileUploader : IFileUploader
{
    private const long MaxBytes = 10 * 1024 * 1024;
    private static readonly string[] ImageExt = { ".jpg", ".jpeg", ".png", ".webp", ".gif" };
    private static readonly string[] DocExt = { ".pdf", ".doc", ".docx", ".xls", ".xlsx" };

    private readonly string _root;

    public FileUploader(IWebHostEnvironment env)
    {
        _root = Path.Combine(env.WebRootPath ?? Path.Combine(env.ContentRootPath, "wwwroot"), "uploads");
        Directory.CreateDirectory(_root);
    }

    public async Task<(string? Path, string? Error)> SaveAsync(IFormFile file, bool imageOnly)
    {
        if (file.Length == 0) return (null, "The file is empty.");
        if (file.Length > MaxBytes) return (null, "File is larger than 10 MB.");

        var ext = Path.GetExtension(file.FileName).ToLowerInvariant();
        var allowed = imageOnly ? ImageExt : ImageExt.Concat(DocExt).ToArray();
        if (!allowed.Contains(ext)) return (null, "Allowed types: " + string.Join(", ", allowed));

        var head = new byte[8];
        await using (var s = file.OpenReadStream())
        {
            var read = await s.ReadAsync(head.AsMemory(0, 8));
            if (read < 4 || !SignatureMatches(ext, head)) return (null, "File content does not match its extension.");
        }

        var name = Guid.NewGuid().ToString("N") + ext;
        await using (var fs = File.Create(Path.Combine(_root, name)))
        {
            await file.CopyToAsync(fs);
        }
        return ("/uploads/" + name, null);
    }

    public void Delete(string? path)
    {
        if (string.IsNullOrEmpty(path) || !path.StartsWith("/uploads/") || path.Contains("..")) return;
        var full = Path.Combine(_root, Path.GetFileName(path));
        try { if (File.Exists(full)) File.Delete(full); } catch { /* best effort */ }
    }

    private static bool SignatureMatches(string ext, byte[] h) => ext switch
    {
        ".pdf" => h[0] == 0x25 && h[1] == 0x50 && h[2] == 0x44 && h[3] == 0x46,
        ".png" => h[0] == 0x89 && h[1] == 0x50 && h[2] == 0x4E && h[3] == 0x47,
        ".jpg" or ".jpeg" => h[0] == 0xFF && h[1] == 0xD8,
        ".gif" => h[0] == 0x47 && h[1] == 0x49 && h[2] == 0x46,
        ".webp" => h[0] == 0x52 && h[1] == 0x49 && h[2] == 0x46 && h[3] == 0x46,
        ".docx" or ".xlsx" => h[0] == 0x50 && h[1] == 0x4B,
        ".doc" or ".xls" => h[0] == 0xD0 && h[1] == 0xCF,
        _ => false
    };
}
