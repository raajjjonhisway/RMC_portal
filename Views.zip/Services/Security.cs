using System.Security.Cryptography;
using System.Text.RegularExpressions;

namespace RanchiMunicipal.Services;

public static class PasswordHelper
{
    private const int Iterations = 210_000;

    public static string Hash(string password)
    {
        var salt = RandomNumberGenerator.GetBytes(16);
        var key = Rfc2898DeriveBytes.Pbkdf2(password, salt, Iterations, HashAlgorithmName.SHA256, 32);
        return $"v1.{Iterations}.{Convert.ToBase64String(salt)}.{Convert.ToBase64String(key)}";
    }

    public static bool Verify(string password, string stored)
    {
        try
        {
            var p = stored.Split('.');
            if (p.Length != 4 || p[0] != "v1") return false;
            var iterations = int.Parse(p[1]);
            var salt = Convert.FromBase64String(p[2]);
            var expected = Convert.FromBase64String(p[3]);
            var actual = Rfc2898DeriveBytes.Pbkdf2(password, salt, iterations, HashAlgorithmName.SHA256, expected.Length);
            return CryptographicOperations.FixedTimeEquals(actual, expected);
        }
        catch
        {
            return false;
        }
    }

    public static string RandomPassword(int length = 14)
    {
        const string chars = "ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnpqrstuvwxyz23456789";
        var sb = new System.Text.StringBuilder();
        for (var i = 0; i < length; i++) sb.Append(chars[RandomNumberGenerator.GetInt32(chars.Length)]);
        return sb.ToString();
    }
}

/// <summary>
/// Defence-in-depth clean-up for admin-authored HTML. Admins are trusted users; this strips the
/// most common script-injection vectors but is not a replacement for a full HTML sanitizer library.
/// </summary>
public static class HtmlCleaner
{
    private const string Bad = "script|iframe|object|embed|style|link|meta|form|base";
    private static readonly Regex Blocks = new($@"<\s*({Bad})\b[^>]*>.*?<\s*/\s*\1\s*>", RegexOptions.Singleline | RegexOptions.IgnoreCase);
    private static readonly Regex Singles = new($@"<\s*/?\s*({Bad})\b[^>]*>", RegexOptions.IgnoreCase);
    private static readonly Regex OnAttr = new(@"\son\w+\s*=\s*(""[^""]*""|'[^']*'|[^\s>]+)", RegexOptions.IgnoreCase);
    private static readonly Regex JsUrl = new(@"(href|src)\s*=\s*([""']?)\s*(javascript|vbscript|data):[^""'>\s]*\2", RegexOptions.IgnoreCase);

    public static string Clean(string? html)
    {
        if (string.IsNullOrEmpty(html)) return "";
        html = Blocks.Replace(html, "");
        html = Singles.Replace(html, "");
        html = OnAttr.Replace(html, "");
        html = JsUrl.Replace(html, "$1=\"#\"");
        return html;
    }
}
