using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Caching.Memory;
using RanchiMunicipal.Data;
using RanchiMunicipal.Models;

namespace RanchiMunicipal.Services;

public interface ISiteService
{
    SiteInfo GetSite();
    NavModel GetNav();
    void Invalidate();
}

public class SiteService : ISiteService
{
    private const string SiteKey = "rmc.site";
    private const string NavKey = "rmc.nav";

    private readonly AppDbContext _db;
    private readonly IMemoryCache _cache;

    public SiteService(AppDbContext db, IMemoryCache cache)
    {
        _db = db;
        _cache = cache;
    }

    public SiteInfo GetSite() => _cache.GetOrCreate(SiteKey, entry =>
    {
        entry.AbsoluteExpirationRelativeToNow = TimeSpan.FromMinutes(5);
        var d = _db.Settings.AsNoTracking().ToDictionary(s => s.Key, s => s.Value);
        string G(string k) => d.TryGetValue(k, out var v) && !string.IsNullOrWhiteSpace(v) ? v : SettingKeys.Default(k);
        return new SiteInfo(G("NameEn"), G("NameHi"), G("Tagline"), G("TollFree"), G("WhatsApp"), G("Email"), G("Address"),
            G("MobileAppUrl"), G("Facebook"), G("Twitter"), G("Instagram"), G("YouTube"),
            G("Ticker"), G("SmartCityUrl"), G("SwachhUrl"),
            G("MenuStyle"), G("HomeDesign"), G("AdminDesign"));
    })!;

    public NavModel GetNav() => _cache.GetOrCreate(NavKey, entry =>
    {
        entry.AbsoluteExpirationRelativeToNow = TimeSpan.FromMinutes(5);
        var items = _db.MenuItems.AsNoTracking().Where(m => m.IsActive).OrderBy(m => m.SortOrder).ThenBy(m => m.Id).ToList();
        List<MenuItem> For(string s) => items.Where(i => i.Section == s).ToList();
        return new NavModel
        {
            Main = MenuSections.Main.Select(m => new NavSection(m.Title, m.Css, For(m.Title))).ToList(),
            MobileApps = For(MenuSections.Apps),
            Websites = For(MenuSections.Sites),
            Online = For(MenuSections.Online)
        };
    })!;

    public void Invalidate()
    {
        _cache.Remove(SiteKey);
        _cache.Remove(NavKey);
    }
}
