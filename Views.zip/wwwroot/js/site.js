(function () {
    'use strict';
    var $ = function (s, r) { return (r || document).querySelector(s); };
    var $$ = function (s, r) { return Array.prototype.slice.call((r || document).querySelectorAll(s)); };
    var reduceMotion = window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches;

    /* ---------- Dropdown menus (click / keyboard; hover handled in CSS on desktop) ---------- */
    $$('.has-dd > .dd-trigger').forEach(function (btn) {
        btn.addEventListener('click', function (e) {
            e.stopPropagation();
            var li = btn.parentElement;
            var wasOpen = li.classList.contains('open');
            $$('.has-dd.open').forEach(function (x) { x.classList.remove('open'); $('.dd-trigger', x).setAttribute('aria-expanded', 'false'); });
            if (!wasOpen) { li.classList.add('open'); btn.setAttribute('aria-expanded', 'true'); }
        });
    });
    document.addEventListener('click', function () {
        $$('.has-dd.open').forEach(function (x) { x.classList.remove('open'); });
    });
    document.addEventListener('keydown', function (e) {
        if (e.key === 'Escape') $$('.has-dd.open').forEach(function (x) { x.classList.remove('open'); });
    });

    var navToggle = $('.nav-toggle'), mainNav = $('#mainNav');
    if (navToggle) navToggle.addEventListener('click', function () {
        var open = mainNav.classList.toggle('open');
        navToggle.setAttribute('aria-expanded', open);
    });

    /* ---------- Text size & contrast (remembered) ---------- */
    var sizes = [14, 16, 18, 20], sizeIdx = 1;
    function applySize() { document.documentElement.style.setProperty('--base-size', sizes[sizeIdx] + 'px'); }
    try { var s = parseInt(localStorage.getItem('rmc-size'), 10); if (s >= 0 && s < sizes.length) sizeIdx = s; } catch (e) { }
    applySize();
    $$('[data-font]').forEach(function (b) {
        b.addEventListener('click', function () {
            var d = parseInt(b.dataset.font, 10);
            sizeIdx = d === 0 ? 1 : Math.max(0, Math.min(sizes.length - 1, sizeIdx + d));
            applySize();
            try { localStorage.setItem('rmc-size', sizeIdx); } catch (e) { }
        });
    });
    try { if (localStorage.getItem('rmc-contrast') === 'dark') document.body.classList.add('high-contrast'); } catch (e) { }
    $$('[data-contrast]').forEach(function (b) {
        b.addEventListener('click', function () {
            var dark = b.dataset.contrast === 'dark';
            document.body.classList.toggle('high-contrast', dark);
            try { localStorage.setItem('rmc-contrast', dark ? 'dark' : 'light'); } catch (e) { }
        });
    });

    /* ---------- Language (Google Translate) ---------- */
    var lang = $('#langSelect');
    if (lang) lang.addEventListener('change', function () {
        var v = lang.value;
        document.cookie = 'googtrans=/en/' + v + '; path=/';
        location.reload();
    });

    /* ---------- Hero carousel ---------- */
    var hero = $('.hero');
    if (hero) {
        var slides = $$('.hero-slide', hero), cur = 0, paused = reduceMotion, timer;
        var pauseBtn = $('.hero-pause', hero);
        function show(i) {
            cur = (i + slides.length) % slides.length;
            slides.forEach(function (s, n) {
                s.classList.toggle('active', n === cur);
                s.setAttribute('aria-hidden', n === cur ? 'false' : 'true');
            });
        }
        function start() { stop(); if (!paused && slides.length > 1) timer = setInterval(function () { show(cur + 1); }, 6000); }
        function stop() { clearInterval(timer); }
        function syncPause() {
            pauseBtn.innerHTML = paused ? '<i class="bi bi-play-fill"></i>' : '<i class="bi bi-pause-fill"></i>';
            pauseBtn.setAttribute('aria-label', paused ? 'Play slideshow' : 'Pause slideshow');
        }
        $('.hero-arrow.prev', hero).addEventListener('click', function () { show(cur - 1); start(); });
        $('.hero-arrow.next', hero).addEventListener('click', function () { show(cur + 1); start(); });
        pauseBtn.addEventListener('click', function () { paused = !paused; syncPause(); start(); });
        syncPause(); start();
    }

    /* ---------- News carousel ---------- */
    var track = $('#newsTrack'), dotsBox = $('#newsDots'), newsPauseBtn = $('#newsPause');
    if (track) {
        var cards = $$('.news-card', track), page = 0, newsPaused = reduceMotion, nTimer;
        function perView() { return Math.max(1, Math.round(track.parentElement.clientWidth / cards[0].getBoundingClientRect().width)); }
        function pages() { return Math.max(1, Math.ceil(cards.length / perView())); }
        function buildDots() {
            dotsBox.innerHTML = '';
            for (var i = 0; i < pages(); i++) {
                var b = document.createElement('button');
                b.type = 'button'; b.setAttribute('aria-label', 'News page ' + (i + 1));
                (function (n) { b.addEventListener('click', function () { go(n); restart(); }); })(i);
                dotsBox.appendChild(b);
            }
            dotsBox.removeAttribute('aria-hidden');
        }
        function go(p) {
            var total = pages();
            page = (p + total) % total;
            var offset = Math.min(page * perView(), cards.length - perView()) * cards[0].getBoundingClientRect().width;
            track.style.transform = 'translateX(' + (-offset) + 'px)';
            $$('button', dotsBox).forEach(function (d, n) { d.classList.toggle('active', n === page); });
        }
        function restart() { clearInterval(nTimer); if (!newsPaused) nTimer = setInterval(function () { go(page + 1); }, 5000); }
        newsPauseBtn.addEventListener('click', function () {
            newsPaused = !newsPaused;
            $('span', newsPauseBtn).textContent = newsPaused ? 'Play' : 'Pause';
            $('i', newsPauseBtn).className = 'bi ' + (newsPaused ? 'bi-play-fill' : 'bi-pause-fill');
            restart();
        });
        window.addEventListener('resize', function () { buildDots(); go(0); });
        buildDots(); go(0); restart();
    }

    /* ---------- Gallery lightbox ---------- */
    var lbTriggers = $$('[data-lightbox]');
    if (lbTriggers.length) {
        var lb = document.createElement('div');
        lb.className = 'lightbox';
        lb.setAttribute('role', 'dialog');
        lb.setAttribute('aria-modal', 'true');
        lb.setAttribute('aria-hidden', 'true');
        lb.innerHTML = '<button type="button" class="lightbox-close" aria-label="Close">&times;</button>' +
            '<button type="button" class="lightbox-arrow prev" aria-label="Previous photo"><i class="bi bi-chevron-left"></i></button>' +
            '<figure><img alt="" /><figcaption></figcaption></figure>' +
            '<button type="button" class="lightbox-arrow next" aria-label="Next photo"><i class="bi bi-chevron-right"></i></button>';
        document.body.appendChild(lb);
        var lbImg = $('img', lb), lbCap = $('figcaption', lb), lbIdx = 0;
        function openLb(i) {
            lbIdx = (i + lbTriggers.length) % lbTriggers.length;
            var t = lbTriggers[lbIdx];
            lbImg.src = t.getAttribute('href') || t.dataset.lightbox;
            lbImg.alt = t.dataset.title || '';
            lbCap.textContent = t.dataset.title || '';
            lb.classList.add('open');
            lb.setAttribute('aria-hidden', 'false');
            document.body.classList.add('lightbox-lock');
        }
        function closeLb() {
            lb.classList.remove('open');
            lb.setAttribute('aria-hidden', 'true');
            document.body.classList.remove('lightbox-lock');
        }
        lbTriggers.forEach(function (t, i) {
            t.addEventListener('click', function (e) { e.preventDefault(); openLb(i); });
        });
        $('.lightbox-close', lb).addEventListener('click', closeLb);
        $('.lightbox-arrow.prev', lb).addEventListener('click', function () { openLb(lbIdx - 1); });
        $('.lightbox-arrow.next', lb).addEventListener('click', function () { openLb(lbIdx + 1); });
        lb.addEventListener('click', function (e) { if (e.target === lb) closeLb(); });
        document.addEventListener('keydown', function (e) {
            if (!lb.classList.contains('open')) return;
            if (e.key === 'Escape') closeLb();
            else if (e.key === 'ArrowLeft') openLb(lbIdx - 1);
            else if (e.key === 'ArrowRight') openLb(lbIdx + 1);
        });
    }

    /* ---------- Social rail & back-to-top ---------- */
    var rail = $('.social-rail');
    if (rail) $('.rail-toggle', rail).addEventListener('click', function () { rail.classList.toggle('collapsed'); });
    var top = $('#backToTop');
    window.addEventListener('scroll', function () { top.classList.toggle('show', window.scrollY > 300); }, { passive: true });
    top.addEventListener('click', function () { window.scrollTo({ top: 0, behavior: reduceMotion ? 'auto' : 'smooth' }); });
})();
